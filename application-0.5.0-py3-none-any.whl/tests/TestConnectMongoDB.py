import unittest

from application.ConnectMongoDB import ConnectMongoDB


class ConnectMongoDBTestCase(unittest.TestCase):
    def setUp(self):
        self.connection = ConnectMongoDB("MEDVERTEX","DATABASENAME")


    def test_database_name(self):
        result = self.connection.get_database_name()
        self.assertEqual(result, "DATABASENAME")



if __name__ == '__main__':
    unittest.main()

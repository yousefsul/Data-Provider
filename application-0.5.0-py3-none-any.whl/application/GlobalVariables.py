import datetime

import shortuuid


class GlobalVariables:
    def __init__(self):
        self.__support_email = "yousefsuliman321@gmail.com"
        self.__support_email_password = "yousef123Y"
        self.__mongo_client_string = "mongodb+srv://yousef:3h2rSzl0pPItpyGp@cluster0.umnlp.mongodb.net" \
                                     "/client_2731928905_DB?retryWrites=true&w=majority"

        self.__html = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>MEDVERTEX EMAIL NOTIFICATION</title>
        </head>

            <body>
                <div class="email_header">
                    <h5 style="color: #e72e0f">MEDVERTEX EMAIL NOTIFICATION</h5>
                </div>

                <div class="email_body">
                    <p>Hello,<br><br>
                       Hope this email finds you well,
                       Please find the attachment file.need your action. <br>
                    </p>
                    <h5>
                       <a href="https://www.medvertex.com">MEDVERTEX</a>
                    </h5>
                </div>
            </body>
        </html>
        """
        self.__text = """\
        File Notification,
        www.medvertex.com"""
        self.__date = datetime.datetime.now().date().strftime("%Y%m%d")
        self.__time = datetime.datetime.now().time().strftime("%H:%M:%S")
        self.__logging_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        self.__log_file_name = self.__date + self.__time
        self.__id = shortuuid.ShortUUID().random().lower()
        self.__current_status_dict = {}
        self.__status = 'new'
        self.__current_status_history = {}

    def get_logging_format(self):
        return self.__logging_format

    def set_logging_format(self, logging_format):
        self.__logging_format = logging_format
        return self.__logging_format

    def get_support_email(self):
        return self.__support_email

    def set_support_email(self, support_email):
        self.__support_email = support_email
        return self.__support_email

    def get_support_email_password(self):
        return self.get_support_email_password()

    def set_support_email_password(self, support_email_password):
        self.__support_email_password = support_email_password
        return self.__support_email_password

    def get_mongo_client_string(self):
        return self.__mongo_client_string

    def set_mongo_client_string(self, mongo_client_string):
        self.__mongo_client_string = mongo_client_string
        return self.__mongo_client_string

    def set_html(self, html):
        self.__html = html
        return self.__html

    def set_text(self, text):
        self.__text = text
        return self.__text

    def get_html(self):
        return self.__html

    def get_text(self):
        return self.__text

    def get_log_file_name(self):
        return self.__log_file_name

    def set_log_file_name(self, log_file_name):
        self.__log_file_name = log_file_name
        return self.__log_file_name

    def set_numeric_random_id(self, id_length):
        self.__id = int(shortuuid.ShortUUID(alphabet="0123456789").random(length=id_length).lower())
        return self.__id

    def set_alphanumeric_random_id(self, id_length):
        self.__id = shortuuid.ShortUUID().random(length=id_length).lower()
        return self.__id

    def get_alphanumeric_random_id(self):
        return self.__id

    def get_header(self, status):
        self.__status = status
        self.__current_status_dict = {
            "status": self.__status,
            "date": {
                "date": self.__date,
                "time": self.__time
            },
            "status_history": [self.__get_current_status_history()],
        }
        return self.__current_status_dict

    def __get_current_status_history(self):
        self.__current_status_history = {
            "status": self.__status,
            "date": {
                "date": self.__date,
                "time": self.__time
            }
        }
        return self.__current_status_history

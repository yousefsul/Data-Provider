import datetime
from pymongo import MongoClient

MONGO_CLIENT = "mongodb+srv://yousef:3h2rSzl0pPItpyGp@cluster0.umnlp.mongodb.net/client_2731928905_DB" \
               "?retryWrites=true&w=majority"
"""
class ConnectMongoDB

Methods:

constructor  -->
    no params

    call from --> search_new_visits,create_claims method in CreateClaims class
----------------------------------------------------------
 connect_to_visits_collection -->
    no params

    call from --> search_new_visits method
-------------------------------------------------------------
 get_visits_data -->
    no params

    call from --> search_new_visits method
----------------------------------------------------------
 connect_to_client_collection -->
    no params

    call from --> create_claims method
    
----------------------------------------------------------
 get_afroza_ahmed_info -->
    no params

    call from --> create_claims method    
----------------------------------------------------------
 connect_to_claims_collection -->
    no params

    call from --> create_claims method    
----------------------------------------------------------
 insert_to_claims_collection -->
    params result 

    call from --> create_claims method    
----------------------------------------------------------

 update_status_for_visits_collection -->
    params patient_id 

    call from --> create_claims method    
----------------------------------------------------------

 update_visit_current_status -->
    params patient_id 

    call from --> create_claims method
----------------------------------------------------------
Functions:
"""


class ConnectMongoDBClaims:
    """
    connect to devDB and client database
    define the clients_collection,visits_collection,claims_collection as none
    """
    def __init__(self):
        try:
            self.__mongo_client = MongoClient(MONGO_CLIENT)
            self.__client_db = self.__mongo_client.client_2731928905_DB
            self.__dev_db = self.__mongo_client.devDB
            self.__clients_collection = None
            self.__visits_collection = None
            self.__claims_collection = None
        except ConnectionError:
            print(ConnectionError, "connection error have been occured")

    # connect to visits collection
    def connect_to_visits_collection(self):
        self.__visits_collection = self.__client_db.visitsColl

    # get the visits that have status new
    def get_visits_data(self):
        return self.__visits_collection.find({"header_section.current_status.status": "new"})

    # connect to clients collection
    def connect_to_client_collection(self):
        self.__clients_collection = self.__dev_db.clientsColl

    # get client afroza ahmed information
    def get_afroza_ahmed_info(self):
        return self.__clients_collection.find_one(
            {
                "client_info.contact.first": "Afroza",
                "client_info.contact.last": "Ahmed"
            }
        )

    # connect to claims collection
    def connect_to_claims_collection(self):
        self.__claims_collection = self.__client_db.claimsColl

    # insert claims
    def insert_to_claims_collection(self, result):
        try:
            self.__claims_collection.insert(result)
        except Exception as e:
            print("An Exception occurred ", e)

    # update the status history in the visits collection in the header section using patient id
    def update_status_for_visits_collection(self, patient_id):
        self.__visits_collection.update_one(
            {"patient_info.patient_id": patient_id},
            {"$push": {
                "header_section.status_history": {
                    "status": "claim created",
                    "date": {
                        "date": datetime.datetime.now().date().strftime("%Y%m%d"),
                        "time": datetime.datetime.now().time().strftime("%H:%M:%S")
                    }
                }
            }}
        )

    # update the current status in the visits collection in the header section using patient id
    def update_visit_current_status(self, patient_id):
        self.__visits_collection.find_and_modify(
            query={"patient_info.patient_id": patient_id},
            update={"$set": {
                "header_section.current_status.status": "claim created",
                "header_section.current_status.date": {
                    "date": datetime.datetime.now().date().strftime("%Y%m%d"),
                    "time": datetime.datetime.now().time().strftime("%H:%M:%S")
                }}
            },
            upsert=True
        )

    def close_connection(self):
        self.__mongo_client.close()

from pymongo import MongoClient
import datetime

# Define constant connection string 
MONGO_CLIENT = "mongodb+srv://yousef:3h2rSzl0pPItpyGp@cluster0.umnlp.mongodb.net/client_2731928905_DB" \
               "?retryWrites=true&w=majority"

"""
class ConnectMongoDB

Methods:
constructor  --> 
    params : no params 
    
    call from --> CreateInputFile Class --> constructor 
----------------------------------------------------------
connect_to_claims_collection -->
    no params
    
    call from --> CreateInputFile Class --> search_new_claims method 
----------------------------------------------------------
connect_to_claims_collection -->
    no params
    
    call from --> CreateInputFile Class --> search_new_claims method 
----------------------------------------------------------
connect_to_claims_collection -->
    no params
    
    call from --> CreateInputFile Class --> search_new_claims method 
----------------------------------------------------------
update_status_for_claims_collection -->
    params --> subscriber_id
    
    call from --> CreateInputFile Class --> construct_input_file_claims method 
----------------------------------------------------------
update_claims_header_section -->
    params --> subscriber_id , FILENAME
    
    call from --> CreateInputFile Class --> construct_input_file_claims method 
----------------------------------------------------------
Functions: 
"""


class ConnectMongoDBReqFile:
    """
    define the connection to MongoDB , database name
    """

    def __init__(self):
        try:
            self.__mongo_client = MongoClient(MONGO_CLIENT)
            self.__db = self.__mongo_client.client_2731928905_DB
            self.__claims_collection = None
        except ConnectionError:
            print("Failed connection to MongoDB")

    """
    define the collection in database named claimsColl
    """

    def connect_to_claims_collection(self):
        self.__claims_collection = self.__db.claimsColl

    """
    retrieve the data in the claims collection 
    """

    def get_claims_data(self):
        return self.__claims_collection.find({"$and": [{"header_section.current_status.status": "new"},
                                                     {"payer.payer_id": "53589"}]
                                            })

    """
    update the header section add the claim status to the array 
    """

    def update_status_for_claims_collection(self, patient_id):
        self.__claims_collection.update_one(
            {"subscriber.patient_id": patient_id},
            {"$push": {
                "header_section.status_history": {
                    "status": "awaiting submission",
                    "date": {
                        "date": datetime.datetime.now().date().strftime("%Y%m%d"),
                        "time": datetime.datetime.now().time().strftime("%H:%M:%S")
                    }
                }
            }}
        )

    """
    update the header section  make the status for the claim awaiting submission
    add the input file name to the header section  
    """

    def update_claims_header_section(self, patient_id, FILE_NAME):
        self.__claims_collection.find_and_modify(
            query={"subscriber.patient_id": patient_id},
            update={"$set": {
                "header_section.current_status.status": "awaiting submission",
                "header_section.current_status.date": {
                    "date": datetime.datetime.now().date().strftime("%Y%m%d"),
                    "time": datetime.datetime.now().time().strftime("%H:%M:%S")
                },
                "header_section.request_file_name": FILE_NAME
            }},
            upsert=True
        )

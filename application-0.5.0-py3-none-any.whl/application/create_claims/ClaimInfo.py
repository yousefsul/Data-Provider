class ClaimInfo:
    def __init__(self, claim_info, client_info):
        self.__claim_info = claim_info
        self.__client_info = client_info
        self.__billing_provider_info = {}
        self.__subscriber_info = {}
        self.__billing_provider_contact = {}
        self.__payer_info = {}
        self.__claim = {}
        self.__facility_info = {}

    def get_billing_provider_info(self):
        self.__billing_provider_info = {
            "loop": "2010AA",
            "billing_provider_id": self.get_billing_provider_id(),
            "npi": self.get_billing_npi(),
            "type": self.get_billing_provider_type(),
            "name": self.get_billing_provider_name(),
            "address": self.get_billing_provider_address(),
            "contact": self.get_billing_provider_contact(),
            "tax_id": self.get_billing_provider_tax_id()
        }
        return self.__billing_provider_info

    def get_billing_provider_id(self):
        return self.__claim_info.get("billing_provider_info")["billing_provider_id"]

    def get_billing_npi(self):
        return self.__claim_info.get("billing_provider_info")["npi"]

    def get_billing_provider_type(self):
        return self.__claim_info.get("billing_provider_info")["entity_type"]

    def get_billing_provider_name(self):
        return self.__claim_info.get("billing_provider_info")["billing_provider_name"]

    def get_billing_provider_address(self):
        return self.__claim_info.get("billing_provider_info")["address"]

    def get_billing_provider_tax_id(self):
        return self.__claim_info.get("billing_provider_info")["tax_id"]

    def get_billing_provider_contact(self):
        self.__billing_provider_contact = {
            "name": self.__client_info.get("client_info")["contact"]["first"] + " " +
                    self.__client_info.get("client_info")["contact"]["last"]
            ,
            "type": "TE",
            "phone_number": self.__client_info.get("client_info")["phone"]
        }
        return self.__billing_provider_contact

    def get_subscriber_info(self):
        self.__subscriber_info = {
            "loop": "2010BA",
            "ins_type": self.get_subscriber_ins_type(),
            "subscriber_type": "1",
            "subscriber_id": self.get_subscriber_id(),
            "patient_id": self.get_patient_id(),
            "group_num": self.get_subscriber_group_num(),
            "plan_name": self.get_subscriber_plan_name(),
            "mcr_secondary_payer_code": "",
            "patient_name": self.get_subscriber_name(),
            "date_of_birth": self.get_subscriber_date_of_birth(),
            "gender": self.get_subscriber_gender(),
            "address": self.get_subscriber_address()
        }
        return self.__subscriber_info

    def get_subscriber_ins_type(self):
        return self.__claim_info.get("patient_info")["account_type"]

    def get_patient_id(self):
        return self.__claim_info.get("patient_info")["patient_id"]

    def get_subscriber_id(self):
        return self.__claim_info.get("insurance_info")["primary_insurance"][0]["subscriber_id"]

    def get_subscriber_group_num(self):
        return self.__claim_info.get("insurance_info")["primary_insurance"][0]["group_number"]

    def get_subscriber_plan_name(self):
        return self.__claim_info.get("insurance_info")["primary_insurance"][0]["plan_name"]

    def get_subscriber_name(self):
        return self.__claim_info.get("patient_info")["patient_name"]

    def get_subscriber_date_of_birth(self):
        return self.__claim_info.get("patient_info")["date_of_birth"]

    def get_subscriber_gender(self):
        return self.__claim_info.get("patient_info")["gender"]

    def get_subscriber_address(self):
        return self.__claim_info.get("patient_info")["address"]

    def get_payer_info(self):
        self.__payer_info = {
            "loop": "2010BB",
            "name": self.get_payer_name(),
            "payer_id": self.get_payer_id(),
            "address": {
                "street_address": self.get_payer_street_address(),
                "city": self.get_payer_city(),
                "state": self.get_payer_state(),
                "zip": self.get_payer_zip()
            }
        }
        return self.__payer_info

    def get_payer_id(self):
        return self.__client_info.get("insurance_info")[0]["payer_id"]

    def get_payer_name(self):
        return self.__claim_info.get("insurance_info")["primary_insurance"][0]["insurance_name"]

    def get_payer_street_address(self):
        return self.__client_info.get("insurance_info")[0]["address"]["street_address"]

    def get_payer_city(self):
        return self.__client_info.get("insurance_info")[0]["address"]["city"]

    def get_payer_state(self):
        return self.__client_info.get("insurance_info")[0]["address"]["state"]

    def get_payer_zip(self):
        return self.__client_info.get("insurance_info")[0]["address"]["zip"]

    def get_claim_info(self):
        self.__claim = {
            "loop": "2300",
            "visit_id": self.get_claim_visit_id(),
            "charges": self.get_claim_charges(),
            "dx_codes": self.get_claim_dx_codes(),
            "frequency": "1",
            "provider_signature_indicator": "Y",
            "accept_assignment": "A",
            "certification": "Y",
            "release_of_info": "Y",
            "authorization": "",
            "onset_of_current_illness": "",
            "referring_provider": self.get_claim_referring_provider(),
            "rendering_provider": self.get_claim_rendering_provider()
        }
        return self.__claim

    def get_claim_visit_id(self):
        return self.__claim_info.get("header_section")["visit_id"]

    def get_claim_charges(self):
        return self.__claim_info.get("service_line")[0]["total_charge"]

    def get_claim_dx_codes(self):
        return self.__claim_info.get("patient_info")["dx_codes"]

    def get_claim_rendering_provider(self):
        rendering_provider = {
            "type": self.__claim_info.get("service_line")[0]["rendering_provider"]["entity_type"],
            "npi": self.__claim_info.get("service_line")[0]["rendering_provider"]["npi"],
            "name": self.__claim_info.get("service_line")[0]["rendering_provider"]["name"],
            "taxonomy": self.__claim_info.get("service_line")[0]["rendering_provider"]["speciality"]["code"]
        }
        return rendering_provider

    def get_claim_referring_provider(self):
        referring_provider = {
            "type": "",
            "npi": "",
            "last_name": "",
            "first_name": "",
            "middle_name": "",
            "suffix": "",
        }
        return referring_provider

    def get_facility_name(self):
        return self.__claim_info.get("service_facility_info")["name"]

    def get_facility_id(self):
        return self.__claim_info.get("service_facility_info")["service_facility_id"]

    def get_facility_type(self):
        return self.__claim_info.get("service_facility_info")["entity_type"]

    def get_facility_npi(self):
        return self.__claim_info.get("service_facility_info")["npi"]

    def get_facility_address(self):
        return self.__claim_info.get("service_facility_info")["address"]

    def get_facility_info(self):
        self.__facility_info = {
            "loop": "2310C",
            "name": self.get_facility_name(),
            "facility_id": self.get_facility_id(),
            "type": self.get_facility_type(),
            "npi": self.get_facility_npi(),
            "address": self.get_facility_address()
        }
        return self.__facility_info

    def get_service_line(self):
        service_line_array = []
        service_line_dic = {
            "date_of_service": self.__claim_info.get("service_line")[0]["date_of_service"],
            "cpt": self.__claim_info.get("service_line")[0]["cpt"],
            "line_note": "",
            "charge": self.__claim_info.get("service_line")[0]["total_charge"],
            "unit": self.__claim_info.get("service_line")[0]["unit"],
            "rendering_provider": self.get_claim_rendering_provider(),
            "modifiers": {
                "mod1": self.__claim_info.get("service_line")[0]["modifiers"]["mod1"],
                "mod2": self.__claim_info.get("service_line")[0]["modifiers"]["mod2"],
                "mod3": self.__claim_info.get("service_line")[0]["modifiers"]["mod3"],
                "mod4": self.__claim_info.get("service_line")[0]["modifiers"]["mod4"]
            },
            "pointer": self.get_dx_code_pointers(),
            "place_of_service": self.__claim_info.get("service_line")[0]["place_of_service"],
            "line_number_control": self.__claim_info.get("service_line")[0]["line_number_control"],
        }
        service_line_array.append(service_line_dic)
        return service_line_array

    def get_dx_code_pointers(self):
        return self.__claim_info.get("service_line")[0]["pointer"]

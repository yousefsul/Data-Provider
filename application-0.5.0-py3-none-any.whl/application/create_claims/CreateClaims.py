import datetime
import shortuuid
from application.create_claims.ClaimInfo import ClaimInfo
from application.mongodb_connection.ConnectMongoDBClaims import ConnectMongoDBClaims

def generate_claim_id():
    return int(shortuuid.ShortUUID(alphabet="0123456789").random(length=12).lower())


def get_current_status():
    current_status = {
        "status": "new",
        "date": {
            "date": datetime.datetime.now().date().strftime("%Y%m%d"),
            "time": datetime.datetime.now().time().strftime("%H:%M:%S")
        }
    }
    return current_status


class CreateClaims:
    """
    define cursor for the visits
    define the current time and date for creating claims
    define the current status history for claim
    create object from class ConnectMongoDB named connection
    """

    def __init__(self):

        self.__visits_data = []
        self.__claim_time = datetime.datetime.now().time().strftime("%H:%M:%S")
        self.__claim_date = datetime.datetime.now().date().strftime("%Y%m%d")
        self.__status_history = [get_current_status()]
        self.__connection = ConnectMongoDBClaims()
        self.__search_new_visits()
        self.__create_claims()

    """
    get the visits when the status of visit new 
    add the cursor 
    """

    def __search_new_visits(self):
        self.__connection.connect_to_visits_collection()
        self.__visits_data = self.__connection.get_visits_data()

    """
    check the cursor if there are no new visits return 
    if the cursor point to new visits extract data for the claim insert the claim to mongodb
    update the current status for visits    
    """

    def __create_claims(self):
        self.__connection.connect_to_client_collection()
        self.__connection.connect_to_claims_collection()
        client_info = self.__connection.get_afroza_ahmed_info()
        for visit in self.__visits_data:
            claim_info = ClaimInfo(visit, client_info)
            patient_id = claim_info.get_patient_id()
            result = {
                "header_section": {
                    "claim_id": generate_claim_id(),
                    "date_created": {
                        "date": self.__claim_date,
                        "time": self.__claim_time
                    },
                    "current_status": get_current_status(),
                    "status_history": [get_current_status()],
                },
                "billing_provider_info": claim_info.get_billing_provider_info(),
                "subscriber": claim_info.get_subscriber_info(),
                "payer": claim_info.get_payer_info(),
                "claim": claim_info.get_claim_info(),
                "facility": claim_info.get_facility_info(),
                "service_line": claim_info.get_service_line()
            }
            self.__connection.insert_to_claims_collection(result)
            self.__connection.update_status_for_visits_collection(patient_id)
            self.__connection.update_visit_current_status(patient_id)
        self.__connection.close_connection()

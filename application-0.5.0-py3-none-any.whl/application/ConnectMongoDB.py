from pymongo import *
from application.GlobalVariables import GlobalVariables


class ConnectMongoDB:
    def __init__(self, database_name):
        try:
            self.__global_var = GlobalVariables()
            self.__mongo_client_name = self.__global_var.get_mongo_client_string()
            self.__mongo_client = MongoClient(self.__mongo_client_name)
            self.__database_name = database_name
            self.__client_database = self.__mongo_client[self.__database_name]
            self.__collection_name = None
        except ConnectionError:
            print("ConnectMongoDB constructor:", ConnectionError)

    def connect_to_collection(self, collection_name):
        self.__collection_name = self.__client_database[collection_name]

    def insert_to_collection(self, result):
        try:
            self.__collection_name.insert(result)
        except Exception as e:
            print("An exception have occurred while inserting to mongodb", e)

    def find_from_collection_by_key(self, key, value):
        return self.__collection_name.find_one({
            key: value
        })

    def find_from_collection(self):
        return self.__collection_name.find({})

    def get_database_name(self):
        return self.__database_name

    def update_one_document_using_key(self, key, value, update_result_dict):
        self.__collection_name.update_one({key, value}, {"$push": update_result_dict})

    def update_modify_one_document_using_key(self, key, value, update_result_dict):
        self.__collection_name.find_and_modify(query={key, value}, update={"$set": update_result_dict}, upsert=True)

    def close_connection(self):
        self.__mongo_client.close()

    def get_number_of_doc_in_collection(self):
        return self.__collection_name.count_documents({})

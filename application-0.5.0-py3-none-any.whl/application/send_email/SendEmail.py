import logging
import smtplib, ssl
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from os.path import basename


class SendEmail:
    def __init__(self, text, html):
        self.__context = None
        self.__sender_address = "yousefsuliman321@gmail.com"
        self.__receiver_address = "yousefsuliman50@gmail.com"
        self.__cc = ["", ""]
        self.__cc = ["akhazaalah@medvertex.com", "cs@medvertex.com", "Madanat@medvertex.com"]
        # self.__cc = ["yousefsuliman9666@gmail.com"]
        self.__password = "yousef123Y"
        self.__message = MIMEMultipart("alternative")
        self.__message["Subject"] = "File Notification"
        self.__message["From"] = self.__sender_address
        self.__message["To"] = self.__receiver_address
        self.__message["Cc"] = self.__set_cc()
        self.__port_number = 465
        self.__smtp_server = "smtp.gmail.com"
        self.__part1 = MIMEText(text, "plain")
        self.__part2 = MIMEText(html, "html")
        self.__part3 = MIMEApplication
        self.__message.attach(self.__part1)
        self.__message.attach(self.__part2)

    def send_email(self, missing_patient_file):
        self.__context = ssl.create_default_context()
        self.__cc.append(self.__receiver_address)
        try:
            with open(missing_patient_file, "rb") as missing_file:
                self.__part3 = MIMEApplication(missing_file.read(), basename(missing_patient_file))
                self.__part3['Content-Disposition'] = 'attachment; filename="%s"' % basename(missing_patient_file)
                self.__message.attach(self.__part3)
            with smtplib.SMTP_SSL(self.__smtp_server, self.__port_number, context=self.__context) as server:
                server.login(self.__sender_address, self.__password)
                server.sendmail(self.__sender_address, self.__cc, str(self.__message))
        except Exception as e:
            logging.info("Exception occurred connection to server or file not found", e)

    def send_email_multi_attachment(self, files_path):
        self.__context = ssl.create_default_context()
        self.__cc.append(self.__receiver_address)
        try:
            for file in files_path:
                with open(file, "rb") as missing_file:
                    self.__part3 = MIMEApplication(missing_file.read(), basename(file))
                    self.__part3['Content-Disposition'] = 'attachment; filename="%s"' % basename(file)
                    self.__message.attach(self.__part3)
            with smtplib.SMTP_SSL(self.__smtp_server, self.__port_number, context=self.__context) as server:
                server.login(self.__sender_address, self.__password)
                server.sendmail(self.__sender_address, self.__cc, str(self.__message))
        except Exception as e:
            logging.info("Exception occurred connection to server or file not found", e)

    def __set_cc(self):
        cc_string = str()
        for count, cc in enumerate(self.__cc):
            cc_string += cc + " "
        return cc_string

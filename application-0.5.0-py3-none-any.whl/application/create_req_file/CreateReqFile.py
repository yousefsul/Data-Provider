import datetime
import fileinput
import glob
import json
import os
import shutil
from pathlib import Path

import shortuuid

# Define claims status and the payer_id for the input-file
from application.create_req_file.ClaimInfo import ClaimInfo
from application.mongodb_connection.ConnectMongoDBReqFile import ConnectMongoDBReqFile

TRANSACTION_TYPE = '837P'
STATUS = "new"
PAYER_ID = "53589"
CLIENT_CODE = 'client_2731928905'
# Define the header and footer section for the input file
header = {
    'client_id': CLIENT_CODE,
    'transaction_type': TRANSACTION_TYPE,
    'payer_id': PAYER_ID
}
submitter_receiver = {
    "submitter": {
        "loop": "loop1000A",
        "id": "",
        "name": "MEDVERTEX",
        "type": "2",
        "contact": "",
        "contact_type1": "TE",
        "value1": "8008931747",
        "contact_type2": "",
        "value2": "",
        "contact_type3": "",
        "value3": ""
    },
    "receiver": {
        "loop": "1000B",
        "id": "",
        "name": "",
        "type": ""
    },
}
groups_num = {
    "groups_num": "1"
}
special_split = '_'
"""
class CreateInputFile

Methods:

constructor  --> 
    params : no params 
    
    call from --> main method 
----------------------------------------------------------
search_new_claims
    no params
    
    call from --> main method 
----------------------------------------------------------
create_input_file -->
    params: final claims list named final_transactions

    call from  --> construct_input_file_claims   
"""


class CreateReqFile:
    """
    create object named connection from class ConnectMongoDB 
    define the lists that will have all claims and the name of the input file 
    """

    def __init__(self):
        self.__connection = ConnectMongoDBReqFile()
        self.__claims_data = []
        self.__transactions = []
        self.__FILE_NAME = CLIENT_CODE + special_split + datetime.datetime.now().strftime(
            "%d%m%Y%H%M") + special_split + shortuuid.ShortUUID().random(
            length=13) + special_split + PAYER_ID + special_split + TRANSACTION_TYPE + ".req"
        Path("837_Request").mkdir(parents=True, exist_ok=True)
        self.__search_new_claims()
        self.__construct_input_file_claims()
        self.__send_file_to_start_processing()

    """
    connect to claims collection by calling method connect_to_claims_collection using connection object 
    store the retrieving data in variable named claims_data
    create object from class Claiminfo named claim_info and send the claim for grapping the data for each claim 
    search the status for each claim in claims data 
    if the status-> new and the payer_id-> "53589" add the result in the transactions list
    """

    def __search_new_claims(self):
        self.__connection.connect_to_claims_collection()
        self.__claims_data = self.__connection.get_claims_data()

    """
    loop in the transactions list extract data using ClaimInfo class getters for each claim
    call update_claims_header_section and update_status_for_claims_collection for updating the claim header section 
    call create_input_file method send the final list as parameter
    """

    def __construct_input_file_claims(self):
        for claim in self.__claims_data:
            claim_info = ClaimInfo(claim)
            patient_id = claim_info.get_patient_id()
            result = {
                "billing_provider": {
                    "loop": claim_info.get_billing_provider_loop(),
                    "npi": claim_info.get_billing_provider_npi(),
                    "type": claim_info.get_billing_provider_type(),
                    "name": claim_info.get_billing_provider_name(),
                    "address": claim_info.get_billing_provider_address(),
                    "city": claim_info.get_billing_provider_city(),
                    "state": claim_info.get_billing_provider_state(),
                    "zip_code": claim_info.get_billing_provider_zip(),
                    "contact": {
                        "name": claim_info.get_billing_provider_contact_name(),
                        "type": claim_info.get_billing_provider_contact_type(),
                        "value": claim_info.get_billing_provider_contact_phone_number()
                    },
                    "tax_id": claim_info.get_billing_provider_tax_id()
                },
                "subscriber": {
                    "loop": claim_info.get_subscriber_loop(),
                    "ins_type": claim_info.get_subscriber_ins_type(),
                    "subscriber_type": claim_info.get_subscriber_type(),
                    "id": claim_info.get_subscriber_id(),
                    "group_num": claim_info.get_subscriber_group_num(),
                    "plan_name": "",
                    "mcr_secondary_payer_code": claim_info.get_subscriber_mcr_secondary_payer_code(),
                    "last_name": claim_info.get_subscriber_last_name(),
                    "first_name": claim_info.get_subscriber_first_name(),
                    "middle_name": claim_info.get_subscriber_middle_name(),
                    "suffix": "",
                    "address": claim_info.get_subscriber_address(),
                    "city": claim_info.get_subscriber_city(),
                    "state": claim_info.get_subscriber_state(),
                    "zip_code": claim_info.get_subscriber_zip(),
                    "date_of_birth": claim_info.get_subscriber_date_of_birth(),
                    "gender": claim_info.get_subscriber_gender(),
                    "hl_id": "2",
                    "hl_parent_id": "1",
                    "child_code": "0"
                },
                "payer": {
                    "loop": claim_info.get_payer_loop(),
                    "type": "",
                    "name": claim_info.get_payer_name(),
                    "id": claim_info.get_payer_id(),
                    "address": claim_info.get_payer_street_address(),
                    "city": claim_info.get_payer_city(),
                    "state": claim_info.get_payer_state(),
                    "zip_code": claim_info.get_payer_zip()
                },
                "claim": {
                    "loop": claim_info.get_claim_loop(),
                    "number": claim_info.get_claim_number(),
                    "charges": claim_info.get_claim_charges(),
                    "DX_code": claim_info.get_claim_dx_codes(),
                    "frequency": claim_info.get_claim_frequency(),
                    "provider_signature_indicator": claim_info.get_claim_provider_signature_indicator(),
                    "accept_assignment": claim_info.get_claim_accept_assignment(),
                    "certification": claim_info.get_claim_certification(),
                    "release_of_info": claim_info.get_claim_release_of_info(),
                    "authorization": claim_info.get_claim_authorization(),
                    "onset_of_current_illness": claim_info.get_claim_onset_of_current_illness(),
                    "referring_provider": claim_info.get_claim_referring_provider(),
                    "rendering_provider": claim_info.get_claim_rendering_provider()
                },
                "facility": {
                    "loop": claim_info.get_facility_loop(),
                    "name": claim_info.get_facility_name(),
                    "type": claim_info.get_facility_type(),
                    "npi": claim_info.get_facility_npi(),
                    "address": claim_info.get_facility_street_address(),
                    "city": claim_info.get_facility_city(),
                    "state": claim_info.get_facility_state(),
                    "zip_code": claim_info.get_facility_zip()
                },
                "service_line": claim_info.get_service_line()
            }
            self.__transactions.append(result)
            self.__connection.update_claims_header_section(patient_id, self.__FILE_NAME)
            self.__connection.update_status_for_claims_collection(patient_id)
        self.__create_input_file()

    """
    create input file with all sections 
    """

    def __create_input_file(self):
        with open(f"837_Request/{self.__FILE_NAME}", 'w') as input_file:
            try:
                json.dump(header, input_file, indent=4)
                json.dump(submitter_receiver, input_file, indent=4)
                json.dump({'transactions': self.__transactions}, input_file, indent=4)
                json.dump(groups_num, input_file, indent=4)
            except Exception as e:
                print(e)
        with fileinput.FileInput(f"837_Request/{self.__FILE_NAME}", inplace=True) as input_file:
            for line in input_file:
                print(line.replace("}{", ","), end='')

    def __send_file_to_start_processing(self):
        destination = '/app/Services/ClaimSubmission/appointment-list/request'
        shutil.copy(f"837_Request/{self.__FILE_NAME}", destination)

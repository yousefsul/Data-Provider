"""
class ClaimInfo

Methods:

constructor  --> 
    params : claim_info 
    
    call from --> CreateInputFile Class --> search_new_claims method 
----------------------------------------------------------
get_claim_status
    no params
    
    call from --> CreateInputFile Class --> search_new_claims method 
----------------------------------------------------------
get_payer_id
    no params
    
    call from --> CreateInputFile Class --> search_new_claims method 
----------------------------------------------------------
getters for each section in claim_info extract the data
----------------------------------------------------------   
"""


class ClaimInfo:
    def __init__(self, claim_info):
        self.__claim_info = claim_info

    def get_claim_status(self):
        return self.__claim_info.get("header_section")["current_status"]["status"]

    def get_billing_provider_loop(self):
        return self.__claim_info.get("billing_provider_info")["loop"]

    def get_billing_provider_npi(self):
        return str(self.__claim_info.get("billing_provider_info")["npi"])

    def get_billing_provider_type(self):
        return self.__claim_info.get("billing_provider_info")["type"]

    def get_billing_provider_name(self):
        return self.__claim_info.get("billing_provider_info")["name"]

    def get_billing_provider_address(self):
        return self.__claim_info.get("billing_provider_info")["address"]["street_address"]

    def get_billing_provider_city(self):
        return self.__claim_info.get("billing_provider_info")["address"]["city"]

    def get_billing_provider_state(self):
        return self.__claim_info.get("billing_provider_info")["address"]["state"]

    def get_billing_provider_zip(self):
        return self.__claim_info.get("billing_provider_info")["address"]["zip"].replace("-", "")

    def get_billing_provider_contact_name(self):
        return self.__claim_info.get("billing_provider_info")["contact"]["name"]

    def get_billing_provider_contact_type(self):
        return self.__claim_info.get("billing_provider_info")["contact"]["type"]

    def get_billing_provider_contact_phone_number(self):
        return str(self.__claim_info.get("billing_provider_info")["contact"]["phone_number"])

    def get_billing_provider_tax_id(self):
        return str(self.__claim_info.get("billing_provider_info")["tax_id"])

    def get_subscriber_loop(self):
        return self.__claim_info.get("subscriber")["loop"]

    def get_patient_id(self):
        return self.__claim_info.get("subscriber")["patient_id"]

    def get_subscriber_ins_type(self):
        return self.__claim_info.get("subscriber")["ins_type"]

    def get_subscriber_type(self):
        return self.__claim_info.get("subscriber")["subscriber_type"]

    def get_subscriber_id(self):
        return self.__claim_info.get("subscriber")["subscriber_id"]

    def get_subscriber_group_num(self):
        return self.__claim_info.get("subscriber")["group_num"]

    def get_subscriber_plan_name(self):
        return self.__claim_info.get("subscriber")["plan_name"]

    def get_subscriber_mcr_secondary_payer_code(self):
        return self.__claim_info.get("subscriber")["mcr_secondary_payer_code"]

    def get_subscriber_last_name(self):
        return self.__claim_info.get("subscriber")["patient_name"]["last"]

    def get_subscriber_first_name(self):
        return self.__claim_info.get("subscriber")["patient_name"]["first"]

    def get_subscriber_middle_name(self):
        return self.__claim_info.get("subscriber")["patient_name"]["middle"]

    def get_subscriber_suffix_name(self):
        return self.__claim_info.get("subscriber")["patient_name"]["suffix"]

    def get_subscriber_address(self):
        return self.__claim_info.get("subscriber")["address"]["street_address"]

    def get_subscriber_city(self):
        return self.__claim_info.get("subscriber")["address"]["city"]

    def get_subscriber_state(self):
        return self.__claim_info.get("subscriber")["address"]["state"]

    def get_subscriber_zip(self):
        return self.__claim_info.get("subscriber")["address"]["zip"]

    def get_subscriber_date_of_birth(self):
        return self.__claim_info.get("subscriber")["date_of_birth"]

    def get_subscriber_gender(self):
        return self.__claim_info.get("subscriber")["gender"]

    def get_payer_name(self):
        return self.__claim_info.get("payer")["name"]

    def get_payer_loop(self):
        return self.__claim_info.get("payer")["loop"]

    def get_payer_id(self):
        return self.__claim_info.get("payer")["payer_id"]

    def get_payer_street_address(self):
        return self.__claim_info.get("payer")["address"]["street_address"]

    def get_payer_city(self):
        return self.__claim_info.get("payer")["address"]["city"]

    def get_payer_state(self):
        return self.__claim_info.get("payer")["address"]["state"]

    def get_payer_zip(self):
        return self.__claim_info.get("payer")["address"]["zip"]

    def get_claim_loop(self):
        return self.__claim_info.get("claim")["loop"]

    def get_claim_number(self):
        return str(self.__claim_info.get("claim")["visit_id"])

    def get_claim_charges(self):
        return str(self.__claim_info.get("claim")["charges"])

    def get_claim_dx_codes(self):
        dx_codes = []
        for dx_code in self.__claim_info.get("claim")["dx_codes"]:
            item = dx_code.replace('.','')
            dx_codes.append(item)
        return dx_codes

    def get_claim_frequency(self):
        return self.__claim_info.get("claim")["frequency"]

    def get_claim_provider_signature_indicator(self):
        return self.__claim_info.get("claim")["provider_signature_indicator"]

    def get_claim_accept_assignment(self):
        return self.__claim_info.get("claim")["accept_assignment"]

    def get_claim_certification(self):
        return self.__claim_info.get("claim")["certification"]

    def get_claim_release_of_info(self):
        return self.__claim_info.get("claim")["release_of_info"]

    def get_claim_authorization(self):
        return self.__claim_info.get("claim")["authorization"]

    def get_claim_onset_of_current_illness(self):
        return self.__claim_info.get("claim")["onset_of_current_illness"]

    def get_claim_referring_provider(self):
        return self.__claim_info.get("claim")["referring_provider"]

    def get_claim_rendering_provider(self):
        rendering_provider = {
            "type": self.__claim_info.get("claim")["rendering_provider"]["type"],
            "npi": str(self.__claim_info.get("claim")["rendering_provider"]["npi"]),
            "first_name": self.__claim_info.get("claim")["rendering_provider"]["name"]["first"],
            "middle_name": "",
            "last_name": self.__claim_info.get("claim")["rendering_provider"]["name"]["last"],
            "suffix": "",
            "taxonomy": self.__claim_info.get("claim")["rendering_provider"]["taxonomy"]
        }
        return rendering_provider

    def get_facility_loop(self):
        return self.__claim_info.get("facility")["loop"]

    def get_facility_name(self):
        return self.__claim_info.get("facility")["name"]

    def get_facility_type(self):
        return self.__claim_info.get("facility")["type"]

    def get_facility_npi(self):
        return str(self.__claim_info.get("facility")["npi"])

    def get_facility_street_address(self):
        return self.__claim_info.get("facility")["address"]["street_address"]

    def get_facility_city(self):
        return self.__claim_info.get("facility")["address"]["city"]

    def get_facility_state(self):
        return self.__claim_info.get("facility")["address"]["state"]

    def get_facility_zip(self):
        return self.__claim_info.get("facility")["address"]["zip"].replace("-" , "")

    def get_service_line(self):
        service_line = []
        result = {}
        for _ in self.__claim_info.get("service_line"):
            result = {
                "dos": self.__claim_info.get("service_line")[0]["date_of_service"],
                "cpt": self.__claim_info.get("service_line")[0]["cpt"],
                "mod1": self.__claim_info.get("service_line")[0]["modifiers"]["mod1"],
                "mod2": self.__claim_info.get("service_line")[0]["modifiers"]["mod2"],
                "mod3": self.__claim_info.get("service_line")[0]["modifiers"]["mod3"],
                "mod4": self.__claim_info.get("service_line")[0]["modifiers"]["mod4"],
                "line_note": self.__claim_info.get("service_line")[0]["line_note"],
                "charge": str(self.__claim_info.get("service_line")[0]["charge"]),
                "num_unit": (str(self.__claim_info.get("service_line")[0]["unit"])),
                "pointer": self.__claim_info.get("service_line")[0]["pointer"],
                "control_number": "1",
                "place_of_service": self.__claim_info.get("service_line")[0]["place_of_service"],
                "line_number_control": str(self.__claim_info.get("service_line")[0]["line_number_control"]),
            }
        service_line.append(result)
        return service_line

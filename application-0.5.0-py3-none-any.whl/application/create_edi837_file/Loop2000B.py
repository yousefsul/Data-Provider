from application.create_edi837_file.utility import check_element_length
import logging

non_critical = logging.getLogger('non_critical.file_873.Loop2000B')
critical = logging.getLogger('critical.file_873.Loop2000B')

class Loop2000B:

    @staticmethod
    def hl_segment(hl_data, subscriber_data):
        non_critical.info('Building the hl segment for Loop2000B')

        hl = hl_data

        # Hierarchical ID Number
        hl01 = check_element_length(hl['HL01']['min'], hl['HL01']['max'], subscriber_data['hl_id'],
                                    hl['HL01']['usage'])

        # Hierarchical Parent ID Number (not used)
        hl02 = check_element_length(hl['HL02']['min'], hl['HL02']['max'], subscriber_data['hl_parent_id'],
                                    hl['HL02']['usage'])

        # Hierarchical Level Code
        hl03 = check_element_length(hl['HL03']['min'], hl['HL03']['max'], hl['HL03']['data'],
                                    hl['HL03']['usage'])

        # Hierarchical Child Code
        hl04 = check_element_length(hl['HL04']['min'], hl['HL04']['max'], subscriber_data['child_code'],
                                    hl['HL04']['usage'])

        hl = 'HL' + '*' + hl01 + '*' + hl02 + '*' + hl03 + '*' + hl04 + '~' #+ '\n'

        return hl

    @staticmethod
    def sbr_segment(sbr_data, subscriber_data):
        non_critical.info('Building the sbr segment for Loop2000B')

        sbr = sbr_data

        # Payer Responsibility Sequence Number Code
        sbr01 = check_element_length(sbr['SBR01']['min'], sbr['SBR01']['max'], subscriber_data['ins_type'],
                                     sbr['SBR01']['usage'])

        # Individual Relationship Code ( SITUATIONAL )
        sbr02 = check_element_length(sbr['SBR02']['min'], sbr['SBR02']['max'], sbr['SBR02']['data'],
                                     sbr['SBR02']['usage'])

        # Reference Identification ( SITUATIONAL )
        sbr03 = check_element_length(sbr['SBR03']['min'], sbr['SBR03']['max'], subscriber_data['group_num'],
                                     sbr['SBR03']['usage'])

        # Plan Name ( SITUATIONAL )
        sbr04 = check_element_length(sbr['SBR04']['min'], sbr['SBR04']['max'], subscriber_data['plan_name'],
                                     sbr['SBR04']['usage'])

        # Insurance Type Code ( SITUATIONAL )
        sbr05 = check_element_length(sbr['SBR05']['min'], sbr['SBR05']['max'],
                                     subscriber_data['mcr_secondary_payer_code'], sbr['SBR05']['usage'])

        # Coordination of Benefits Code ( Not Used )
        # sbr06 = check_element_length(sbr['SBR06']['min'], sbr['SBR06']['max'], sbr['SBR06']['data'],
        # sbr['SBR06']['usage'])
        sbr06 = ""

        # Yes/No Condition or Response Code ( Not Used )
        # sbr07 = check_element_length(sbr['SBR07']['min'], sbr['SBR07']['max'], sbr['SBR07']['data'],
        # sbr['SBR07']['usage'])
        sbr07 = ""

        # Employment Status Code ( Not Used )
        # sbr08 = check_element_length(sbr['SBR08']['min'], sbr['SBR08']['max'], sbr['SBR08']['data'],
        # sbr['SBR08']['usage'])
        sbr08 = ""

        # Claim Filing Indicator Code ( SITUATIONAL )
        sbr09 = check_element_length(sbr['SBR09']['min'], sbr['SBR09']['max'], sbr['SBR09']['data'],
                                     sbr['SBR09']['usage'])

        sbr = 'SBR' + '*' + sbr01 + '*' + sbr02 + '*' + sbr03 + '*' + sbr04 + \
              '*' + sbr05 + '*' + sbr06 + '*' + sbr07 + '*' + sbr08 + '*' + sbr09

        length = len(sbr)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if sbr[i] != '*':
                index = i + 1
                break

        sbr = sbr[0: index]
        sbr += '~' #+ '\n')

        return sbr

    @staticmethod
    def all_loop(hl_data, sbr_data, subscriber_data):
        num_segments = 0

        loop2000B = ""

        loop2000B += Loop2000B.hl_segment(hl_data, subscriber_data)
        num_segments += 1

        loop2000B += Loop2000B.sbr_segment(sbr_data, subscriber_data)
        num_segments += 1

        return loop2000B, num_segments


class Loop2010BA:

    @staticmethod
    def nm1_segment(nm1_data, subscriber_data):
        non_critical.info('Building the nm1 segment for Loop2010BA')

        nm1 = nm1_data

        # Entity Identifier Code
        nm101 = check_element_length(nm1['NM101']['min'], nm1['NM101']['max'], nm1['NM101']['data'],
                                     nm1['NM101']['usage'])

        # Entity Type Qualifier
        nm102 = check_element_length(nm1['NM102']['min'], nm1['NM102']['max'],
                                     subscriber_data['subscriber_type'], nm1['NM102']['usage'])

        # Name Last or Organization Name
        nm103 = check_element_length(nm1['NM103']['min'], nm1['NM103']['max'], subscriber_data['last_name'],
                                     nm1['NM103']['usage'])

        # Name First ( SITUATIONAL )
        nm104 = check_element_length(nm1['NM104']['min'], nm1['NM104']['max'], subscriber_data['first_name'],
                                     nm1['NM104']['usage'])

        # Name Middle ( SITUATIONAL )
        nm105 = check_element_length(nm1['NM105']['min'], nm1['NM105']['max'], subscriber_data['middle_name'],
                                     nm1['NM105']['usage'])

        # Name Prefix ( Not Used )
        # nm106 = check_element_length(nm1['NM106']['min'], nm1['NM106']['max'], nm1['NM106']['data'],
        # nm1['NM106']['data'])
        nm106 = ""

        # Name Suffix ( SITUATIONAL )
        nm107 = check_element_length(nm1['NM107']['min'], nm1['NM107']['max'], subscriber_data['suffix'],
                                     nm1['NM107']['usage'])

        # Identification Code Qualifier
        nm108 = check_element_length(nm1['NM108']['min'], nm1['NM108']['max'], nm1['NM108']['data'],
                                     nm1['NM108']['usage'])

        # Identification Code
        nm109 = check_element_length(nm1['NM109']['min'], nm1['NM109']['max'], subscriber_data['id'],
                                     nm1['NM109']['usage'])

        nm1 = 'NM1' + '*' + nm101 + '*' + nm102 + '*' + nm103 + '*' + nm104 + \
              '*' + nm105 + '*' + nm106 + '*' + nm107 + '*' + nm108 + '*' + nm109

        length = len(nm1)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if nm1[i] != '*':
                index = i + 1
                break

        nm1 = nm1[0: index]
        nm1 += '~' #+ '\n')

        return nm1

    @staticmethod
    def n3_segment(n3_data, subscriber_data):
        non_critical.info('Building the n3 segment for Loop2010BA')

        n3 = n3_data

        # Address Information
        n301 = check_element_length(n3['N301']['min'], n3['N301']['max'], subscriber_data['address'],
                                    n3['N301']['usage'])

        # Address Information ( Not Used In The Default ) ( SITUATIONAL )
        # n302 = check_element_length(n3['N302']['min'], n3['N302']['max'], n3['N302']['data'],
        # n3['N302']['usage'])

        n3 = 'N3' + '*' + n301 + '~' #+ '\n'

        return n3

    @staticmethod
    def n4_segment(n4_data, subscriber_data):
        non_critical.info('Building the n4 segment for Loop2010BA')

        n4 = n4_data

        # City Name
        n401 = check_element_length(n4['N401']['min'], n4['N401']['max'], subscriber_data['city'],
                                    n4['N401']['usage'])

        # State or Province Code ( SITUATIONAL )
        n402 = check_element_length(n4['N402']['min'], n4['N402']['max'], subscriber_data['state'],
                                    n4['N402']['usage'])

        # Postal Code ( SITUATIONAL )
        n403 = check_element_length(n4['N403']['min'], n4['N403']['max'], subscriber_data['zip_code'],
                                    n4['N403']['usage'])

        # Country Code ( Not Used In The Default ) ( SITUATIONAL )
        # n404 = check_element_length(n4['N404']['min'], n4['N404']['max'], n4['N404']['data'],
        # n4['N404']['usage'])

        # Location Qualifier ( not used )
        # n405 = check_element_length(n4['N405']['min'], n4['N405']['max'], n4['N405']['data'],
        # n4['N405']['usage'])
        # n405 = ""

        # Location Identifier ( not used )
        # n406 = check_element_length(n4['N406']['min'], n4['N406']['max'], n4['N406']['data'],
        # n4['N406']['usage'])
        # n406 = ""

        # Country Subdivision Code ( Not Used In The Default ) ( SITUATIONAL )
        # n407 = check_element_length(n4['N407']['min'], n4['N407']['max'], n4['N407']['data'],
        # n4['N407']['usage'])

        n4 = 'N4' + '*' + n401 + '*' + n402 + '*' + n403

        length = len(n4)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if n4[i] != '*':
                index = i + 1
                break

        n4 = n4[0: index]
        n4 += '~' #+ '\n')

        return n4

    @staticmethod
    def dmg_segment(dmg_data, subscriber_data):
        non_critical.info('Building the dmg segment for Loop2010BA')

        dmg = dmg_data

        # Date Time Period Format Qualifier
        dmg01 = check_element_length(dmg['DMG01']['min'], dmg['DMG01']['max'], dmg['DMG01']['data'],
                                     dmg['DMG01']['usage'])

        # Date Time Period
        dmg02 = check_element_length(dmg['DMG02']['min'], dmg['DMG02']['max'], subscriber_data['date_of_birth'],
                                     dmg['DMG02']['usage'])

        # Gender Code
        dmg03 = check_element_length(dmg['DMG03']['min'], dmg['DMG03']['max'], subscriber_data['gender'],
                                     dmg['DMG03']['usage'])

        dmg = 'DMG' + '*' + dmg01 + '*' + dmg02 + '*' + dmg03 + '~' #+ '\n'

        return dmg

    @staticmethod
    def all_loop(nm1_data, n3_data, n4_data, dmg_data, subscriber_data):
        num_segments = 0

        loop2000BA = ""

        loop2000BA += Loop2010BA.nm1_segment(nm1_data, subscriber_data)
        num_segments += 1

        if subscriber_data['address'] != "":
            loop2000BA += Loop2010BA.n3_segment(n3_data, subscriber_data)
            num_segments += 1

        loop2000BA += Loop2010BA.n4_segment(n4_data, subscriber_data)
        num_segments += 1

        if subscriber_data['date_of_birth'] != "" and subscriber_data['gender'] != "":
            loop2000BA += Loop2010BA.dmg_segment(dmg_data, subscriber_data)
            num_segments += 1

        return loop2000BA, num_segments

class Loop2010BB:

    @staticmethod
    def nm1_segment(nm1_data, payer_data, payer_id, payer_name):
        non_critical.info('Building the nm1 segment for Loop2010BB')

        nm1 = nm1_data

        # Entity Identifier Code
        nm101 = check_element_length(nm1['NM101']['min'], nm1['NM101']['max'], nm1['NM101']['data'],
                                     nm1['NM101']['usage'])

        # Entity Type Qualifier
        nm102 = check_element_length(nm1['NM102']['min'], nm1['NM102']['max'], nm1['NM102']['data'],
                                     nm1['NM102']['usage'])

        # Name Last or Organization Name
        nm103 = check_element_length(nm1['NM103']['min'], nm1['NM103']['max'], payer_name,
                                     nm1['NM103']['usage'])

        # Name First ( Not Used )
        # nm104 = check_element_length(nm1['NM104']['min'], nm1['NM104']['max'], nm1['NM104']['data'],
        # nm1['NM104']['usage'])
        nm104 = ""

        # Name Middle ( Not Used )
        # nm105 = check_element_length(nm1['NM105']['min'], nm1['NM105']['max'], nm1['NM105']['data'],
        # nm1['NM105']['usage'])
        nm105 = ""

        # Name Prefix ( Not Used )
        # nm106 = check_element_length(nm1['NM106']['min'], nm1['NM106']['max'], nm1['NM106']['data'],
        # nm1['NM106']['usage'])
        nm106 = ""

        # Name Suffix ( Not Used )
        # nm107 = check_element_length(nm1['NM107']['min'], nm1['NM107']['max'], nm1['NM107']['data'],
        # nm1['NM107']['usage'])
        nm107 = ""

        # Identification Code Qualifier
        nm108 = check_element_length(nm1['NM108']['min'], nm1['NM108']['max'], nm1['NM108']['data'],
                                     nm1['NM108']['usage'])

        # Identification Code
        nm109 = check_element_length(nm1['NM109']['min'], nm1['NM109']['max'], payer_id,
                                     nm1['NM109']['usage'])

        nm1 = 'NM1' + '*' + nm101 + '*' + nm102 + '*' + nm103 + '*' + nm104 + \
              '*' + nm105 + '*' + nm106 + '*' + nm107 + '*' + nm108 + '*' + nm109 + '~' #+ '\n'

        return nm1

    @staticmethod
    def n3_segment(n3_data, payer_data):
        non_critical.info('Building the n3 segment for Loop2010BB')

        n3 = n3_data

        # Address Information
        n301 = check_element_length(n3['N301']['min'], n3['N301']['max'], payer_data['address'],
                                    n3['N301']['usage'])

        # Address Information ( Not Used In The Default ) ( SITUATIONAL )
        # n302 = check_element_length(n3['N302']['min'], n3['N302']['max'], n3['N302']['data'],
        # n3['N302']['usage'])

        n3 = 'N3' + '*' + n301 + '~' #+ '\n'

        return n3

    @staticmethod
    def n4_segment(n4_data, payer_data):
        non_critical.info('Building the n4 segment for Loop2010BB')

        n4 = n4_data

        # City Name
        n401 = check_element_length(n4['N401']['min'], n4['N401']['max'], payer_data['city'],
                                    n4['N401']['usage'])

        city_zip = ""
        # State or Province Code ( SITUATIONAL )
        n402 = check_element_length(n4['N402']['min'], n4['N402']['max'], payer_data['state'],
                                        n4['N402']['usage'])

        city_zip += '*' + n402

        # Postal Code ( SITUATIONAL )
        n403 = check_element_length(n4['N403']['min'], n4['N403']['max'], payer_data['zip_code'],
                                        n4['N403']['usage'])


        # Country Code ( Not Used In The Default ) ( SITUATIONAL )
        # n404 = check_element_length(n4['N404']['min'], n4['N404']['max'], n4['N404']['data'],
        # n4['N404']['usage'])

        # Location Qualifier ( not used )
        # n405 = check_element_length(n4['N405']['min'], n4['N405']['max'], n4['N405']['data'],
        # n4['N405']['usage'])
        # n405 = ""

        # Location Identifier ( not used )
        # n406 = check_element_length(n4['N406']['min'], n4['N406']['max'], n4['N406']['data'],
        # n4['N406']['usage'])
        # n406 = ""

        # Country Subdivision Code ( Not Used In The Default ) ( SITUATIONAL )
        # n407 = check_element_length(n4['N407']['min'], n4['N407']['max'], n4['N407']['data'],
        # n4['N407']['usage'])

        n4 = 'N4' + '*' + n401 + '*' +n402 + '*' + n403

        length = len(n4)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if n4[i] != '*':
                index = i + 1
                break

        n4 = n4[0: index]
        n4 += '~' #+ '\n')

        return n4

    @staticmethod
    def all_loop(nm1_data, n3_data, n4_data, payer_data, payer_id, payer_name):
        num_segments = 0

        loop2010BB = ""

        loop2010BB += Loop2010BB.nm1_segment(nm1_data, payer_data, payer_id, payer_name)
        num_segments += 1

        if payer_data['address'] != "":
            loop2010BB += Loop2010BB.n3_segment(n3_data, payer_data)
            num_segments += 1

        loop2010BB += Loop2010BB.n4_segment(n4_data, payer_data)
        num_segments += 1

        return loop2010BB, num_segments

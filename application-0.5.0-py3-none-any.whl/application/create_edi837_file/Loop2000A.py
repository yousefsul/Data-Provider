from application.create_edi837_file.utility import check_element_length
import logging

non_critical = logging.getLogger('non_critical.file_873.Loop2000A')
critical = logging.getLogger('critical.file_873.Loop2000A')

class Loop2000A:

    @staticmethod
    def hl_segment(hl_data):
        non_critical.info('Building the hl segment for Loop2000A')

        hl = hl_data

        # Hierarchical ID Number
        hl01 = check_element_length(hl['HL01']['min'], hl['HL01']['max'], hl['HL01']['data'],
                                    hl['HL01']['usage'])

        # Hierarchical Parent ID Number (not used)
        # hl02 = check_element_length(hl['HL02']['min'], hl['HL02']['max'], hl['HL02']['data'],
        # hl['HL02']['usage'])
        hl02 = ""

        # Hierarchical Level Code
        hl03 = check_element_length(hl['HL03']['min'], hl['HL03']['max'], hl['HL03']['data'],
                                    hl['HL03']['usage'])

        # Hierarchical Child Code
        hl04 = check_element_length(hl['HL04']['min'], hl['HL04']['max'], hl['HL04']['data'],
                                    hl['HL04']['usage'])

        hl = 'HL' + '*' + hl01 + '*' + hl02 + '*' + hl03 + '*' + hl04 + '~' #+ '\n'

        return hl

    @staticmethod
    def all_loop(hl_data):
        num_segments = 0

        loop2000A = ""

        loop2000A += Loop2000A.hl_segment(hl_data)
        num_segments += 1

        return loop2000A, num_segments


class Loop2010AA:

    @staticmethod
    def nm1_segment(nm1_data, billing_provider_data):
        non_critical.info('Building the nm1 segment for Loop2010AA')

        nm1 = nm1_data

        # Entity Identifier Code
        nm101 = check_element_length(nm1['NM101']['min'], nm1['NM101']['max'], nm1['NM101']['data'],
                                     nm1['NM101']['usage'])

        # Entity Type Qualifier
        nm102 = check_element_length(nm1['NM102']['min'], nm1['NM102']['max'], billing_provider_data['type'],
                                     nm1['NM102']['usage'])

        # Name Last or Organization Name
        nm103 = check_element_length(nm1['NM103']['min'], nm1['NM103']['max'], billing_provider_data['name'],
                                     nm1['NM103']['usage'])

        # Name First ( SITUATIONAL )
        if billing_provider_data['type'] == "1":
            nm104 = check_element_length(nm1['NM104']['min'], nm1['NM104']['max'], billing_provider_data['first_name'],
                                         nm1['NM104']['usage'])
        else:
            nm104 = ""

        # Name Middle ( SITUATIONAL )
        if billing_provider_data['type'] == "1":
            nm105 = check_element_length(nm1['NM105']['min'], nm1['NM105']['max'], billing_provider_data['middle_name'],
                                         nm1['NM105']['usage'])
        else:
            nm105 = ""

        # Name Prefix ( not  used)
        # nm106 = check_element_length(nm1['NM106']['min'], nm1['NM106']['max'], nm1['NM106']['data'],
        # nm1['NM106']['usage'])
        nm106 = ""

        # Name Suffix ( SITUATIONAL )
        if billing_provider_data['type'] == "1":
            nm107 = check_element_length(nm1['NM107']['min'], nm1['NM107']['max'], billing_provider_data['suffix'],
                                     nm1['NM107']['usage'])
        else:
            nm107 = ""

        # Identification Code Qualifier ( SITUATIONAL )
        nm108 = check_element_length(nm1['NM108']['min'], nm1['NM108']['max'], nm1['NM108']['data'],
                                     nm1['NM108']['usage'])

        # Identification Code ( SITUATIONAL )
        nm109 = check_element_length(nm1['NM109']['min'], nm1['NM109']['max'], billing_provider_data['npi'],
                                     nm1['NM109']['usage'])

        nm1 = 'NM1' + '*' + nm101 + '*' + nm102 + '*' + nm103 + '*' + nm104 + \
              '*' + nm105 + '*' + nm106 + '*' + nm107 + '*' + nm108 + '*' + nm109

        length = len(nm1)
        length -= 1
        index = 0
        for i in range(length, 0, -1):
            if nm1[i] != '*':
                index = i + 1
                break

        nm1 = nm1[0:index]
        nm1 += '~' #+ '\n'

        return nm1

    @staticmethod
    def n3_segment(n3_data, billing_provider_data):
        non_critical.info('Building the n3 segment for Loop2010AA')

        n3 = n3_data

        # Address Information
        n301 = check_element_length(n3['N301']['min'], n3['N301']['max'], billing_provider_data['address'],
                                    n3['N301']['usage'])

        # Address Information ( Not Used In The Default ) ( SITUATIONAL )
        # n302 = check_element_length(n3['N302']['min'], n3['N302']['max'], n3['N302']['data'],
        # n3['N301']['usage'])

        n3 = 'N3' + '*' + n301 + '~' #+ '\n'

        return n3

    @staticmethod
    def n4_segment(n4_data, billing_provider_data):
        non_critical.info('Building the n4 segment for Loop2010AA')

        n4 = n4_data

        # City Name
        n401 = check_element_length(n4['N401']['min'], n4['N401']['max'], billing_provider_data['city'],
                                    n4['N401']['usage'])

        # State or Province Code ( SITUATIONAL )
        n402 = check_element_length(n4['N402']['min'], n4['N402']['max'], billing_provider_data['state'],
                                    n4['N402']['usage'])

        # Postal Code ( SITUATIONAL )
        n403 = check_element_length(n4['N403']['min'], n4['N403']['max'], billing_provider_data['zip_code'],
                                    n4['N403']['usage'])

        # Country Code ( Not Used In The Default ) ( SITUATIONAL )
        # n404 = check_element_length(n4['N404']['min'], n4['N404']['max'], n4['N404']['data'],
        # n4['N404']['usage'])

        # Location Qualifier ( not used )
        # n405 = check_element_length(n4['N405']['min'], n4['N405']['max'], n4['N405']['data'],
        # n4['N405']['usage'])
        # n405 = ""

        # Location Identifier ( not used )
        # n406 = check_element_length(n4['N406']['min'], n4['N406']['max'], n4['N406']['data'],
        # n4['N406']['usage'])
        # n406 = ""

        # Country Subdivision Code ( Not Used In The Default ) ( SITUATIONAL )
        # n407 = check_element_length(n4['N407']['min'], n4['N407']['max'], n4['N407']['data'],
        # n4['N407']['usage'])

        n4 = 'N4' + '*' + n401 + '*' + n402 + '*' + n403

        length = len(n4)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if n4[i] != '*':
                index = i + 1
                break

        n4 = n4[0:index]
        n4 += '~' #+ '\n')

        return n4

    @staticmethod
    def ref_segment(ref_data, billing_provider_data):
        non_critical.info('Building the ref segment for Loop2010AA')

        ref = ref_data

        # Reference Identification Qualifier
        ref01 = check_element_length(ref['REF01']['min'], ref['REF01']['max'], ref['REF01']['data'],
                                     ref['REF01']['usage'])

        # Reference Identification Qualifier
        ref02 = check_element_length(ref['REF02']['min'], ref['REF02']['max'], billing_provider_data['tax_id'],
                                     ref['REF02']['usage'])

        ref = 'REF' + '*' + ref01 + '*' + ref02 + '~' #+ '\n'

        return ref

    @staticmethod
    def per_segment(per_data, billing_provider_data):
        non_critical.info('Building the per segment for Loop2010AA')

        per = per_data

        # Contact Function Code
        per01 = check_element_length(per['PER01']['min'], per['PER01']['max'], per['PER01']['data'],
                                     per['PER01']['usage'])

        # Contact Function Code ( SITUATIONAL )
        per02 = check_element_length(per['PER02']['min'], per['PER02']['max'],
                                     billing_provider_data['contact']['name'], per['PER02']['usage'])

        # Contact Function Code
        per03 = check_element_length(per['PER03']['min'], per['PER03']['max'],
                                     billing_provider_data['contact']['type'], per['PER03']['usage'])

        # Contact Function Code
        per04 = check_element_length(per['PER04']['min'], per['PER04']['max'],
                                     billing_provider_data['contact']['value'], per['PER04']['usage'])

        # Contact Function Code ( Not Used In The Default ) ( SITUATIONAL )
        # per05 = check_element_length(per['PER05']['min'], per['PER05']['max'], per['PER05']['data'],
        # per['PER05']['usage'])

        # Contact Function Code ( Not Used In The Default ) ( SITUATIONAL )
        # per06 = check_element_length(per['PER06']['min'], per['PER06']['max'], per['PER06']['data'],
        # per['PER06']['usage'])

        # Contact Function Code ( Not Used In The Default ) ( SITUATIONAL )
        # per07 = check_element_length(per['PER07']['min'], per['PER07']['max'], per['PER07']['data'],
        # per['PER07']['usage'])

        # Contact Function Code ( Not Used In The Default ) ( SITUATIONAL )
        # per08 = check_element_length(per['PER08']['min'], per['PER08']['max'], per['PER08']['data'],
        # per['PER08']['usage'])

        per = 'PER' + '*' + per01 + '*' + per02 + '*' + per03 + \
            '*' + per04 + '~' #+ '\n'

        return per

    @staticmethod
    def all_loop(nm1_data, n3_data, n4_data, ref_data, per_data, billing_provider_data):
        num_segments = 0

        loop2010AA = ""

        loop2010AA += Loop2010AA.nm1_segment(nm1_data, billing_provider_data)
        num_segments += 1

        loop2010AA += Loop2010AA.n3_segment(n3_data, billing_provider_data)
        num_segments += 1

        loop2010AA += Loop2010AA.n4_segment(n4_data, billing_provider_data)
        num_segments += 1

        loop2010AA += Loop2010AA.ref_segment(ref_data, billing_provider_data)
        num_segments += 1

        if billing_provider_data['contact']['type'] != "" and billing_provider_data['contact']['value'] != "":
            loop2010AA += Loop2010AA.per_segment(per_data, billing_provider_data)
            num_segments += 1

        return loop2010AA, num_segments



class Loop2010AB:

    @staticmethod
    def nm1_segment(nm1_data):
        non_critical.info('Building the nm1 segment for Loop2010AB')

        nm1 = nm1_data

        # Entity Identifier Code
        nm101 = check_element_length(nm1['NM101']['min'], nm1['NM101']['max'], nm1['NM101']['data'])

        # Entity Type Qualifier
        nm102 = check_element_length(nm1['NM102']['min'], nm1['NM102']['max'], nm1['NM102']['data'])

        nm1 = 'NM1' + '*' + nm101 + '*' + nm102 + '~' + '\n'

        return nm1

    @staticmethod
    def n3_segment(n3_data):
        non_critical.info('Building the n3 segment for Loop2010AB')
        
        n3 = n3_data

        # Address Information
        n301 = check_element_length(n3['N301']['min'], n3['N301']['max'], n3['N301']['data'])

        n3 = 'N3' + '*' + n301 + '~' + '\n'

        return n3

    @staticmethod
    def n4_segment(n4_data):
        non_critical.info('Building the n4 segment for Loop2010AB')

        n4 = n4_data

        # City Name
        n401 = check_element_length(n4['N401']['min'], n4['N401']['max'], n4['N401']['data'])

        # State or Province Code
        n402 = check_element_length(n4['N402']['min'], n4['N402']['max'], n4['N402']['data'])

        # Postal Code
        n403 = check_element_length(n4['N403']['min'], n4['N403']['max'], n4['N403']['data'])

        # Country Code ( Not Used In The Default )
        # n404 = check_element_length(n4['N404']['min'], n4['N404']['max'], n4['N404']['data'])

        # Location Qualifier ( not used )
        # n405 = check_element_length(n4['N405']['min'], n4['N405']['max'], n4['N405']['data'])
        # n405 = ""

        # Location Identifier ( not used )
        # n406 = check_element_length(n4['N406']['min'], n4['N406']['max'], n4['N406']['data'])
        # n406 = ""

        # Country Subdivision Code ( Not Used In The Default )
        # n407 = check_element_length(n4['N407']['min'], n4['N407']['max'], n4['N407']['data'])

        n4 = 'N4' + '*' + n401 + '*' + n402 + '*' + n403 + '~' + '\n'

    @staticmethod
    def all_loop(nm1_data, n3_data, n4_data):
        loop2010AB = ""
        loop2010AB += Loop2010AB.nm1_segment(nm1_data)
        loop2010AB += Loop2010AB.n3_segment(n3_data)
        loop2010AB += Loop2010AB.n4_segment(n4_data)

        return loop2010AB

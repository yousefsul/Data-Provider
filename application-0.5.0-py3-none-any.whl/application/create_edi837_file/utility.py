import logging

non_critical = logging.getLogger('non_critical.file_873.utility')
critical = logging.getLogger('critical.file_873.utility')

def check_ISA_element(element_length, data):
    data_length = len(data)

    if data_length > element_length:
        try:
            raise("The data is too long in one of the isa elements || Data: " + data)
        except Exception as Ex:
            critical.error(Ex)
            print(Ex)
            return data[0:element_length]

    num_of_spaces = element_length - len(data)
    return data + (' ' * num_of_spaces)


def check_GS_element(element_min_length, element_max_length, data):
    data_length = len(data)
    if (data_length >= element_min_length) and (data_length <= element_max_length):
        return data
    else:
        try:
            raise Exception("The data length is not correct in one of the gs elements || Data: " + data)
        except Exception as Ex:
            critical.error(Ex)
            print(Ex)
            if data_length > element_max_length:
                return data[0:element_max_length]
            else:
                return data + ('0' * (element_min_length - len(data)))


def check_element_length(element_min_length, element_max_length, data, usage):
    data_length = len(data)

    if usage == 's' and data_length == 0:
        return ""
    elif (data_length >= element_min_length) and (data_length <= element_max_length):
        return data
    else:
        try:
            raise Exception("The data length is not correct || Data: " + data)
        except Exception as Ex:
            critical.error(Ex)
            print(Ex)
            if data_length > element_max_length:
                return data[0:element_max_length]
            else:
                return data + ('0' * (element_min_length - len(data)))

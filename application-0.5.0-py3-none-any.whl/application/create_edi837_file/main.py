import re
from itertools import product

import time
import os
import glob
import shutil
import threading
import logging
from application.create_edi837_file.file_837 import Trans837


def execute_file(file, file_num):
    # start = time.time()

    # print("file: " + file)

    file_name = os.path.basename(file)  # Get the file name from the path

    transaction_type = file_name.split('_')[-1].split('.')[0]

    non_critical.info('The file name for this thread is: ' + file_name)
    # print('file_name: ' + file_name)

    if transaction_type == '837P':
        try:
            non_critical.info('Coping the request file to processing folder')
            shutil.copy2(file, './request/processing/' + file_name)  # Copy the request file to the processing folder
        except OSError:
            critical.error('Error in coping the request file to processing folder')
            print("Error in coping the request file to processing folder")

        try:
            non_critical.info('Removing the request file from the request folder')
            os.remove(file)  # Remove the request file from the request folder
        except OSError:
            critical.error('Error in removing the request file from the processing folder')
            print("Error in removing the request file from the processing folder")

        file = './request/processing/' + file_name  # Change the path to the processing folder

        non_critical.info('Creating an object from the Trans837 class')
        file_837 = Trans837('config', file, '53589', '53589')  # Create the Trans837 object
        result = file_837.prepare_the_file()  # Get the result from prepare the file function

        print('result for(' + str(file_num) + '): ' + result)

        try:
            non_critical.info('Coping the request file to processed folder')
            shutil.copy2(file, './request/processed/' + file_name)  # Copy the request file to the processed folder
        except OSError:
            critical.error('Error in coping the request file to processed folder')
            print("Error in coping the request file to processed folder")

        try:
            non_critical.info('Removing the request file from the processing folder')
            os.remove(file)  # Remove the request file from the processing folder
        except OSError:
            critical.error('Error in removing the request file from the processing folder')
            print("Error in removing the request file from the processing folder")

        end = time.time()  # Get the time
        print('elapsed time for(' + str(file_num) + '): ' + str(end - start) + '\n\n')


def receive_files():
    try:
        non_critical.info('Search for all request files inside the request folder')
        requested_files = glob.glob('./request/*.req')  # Search for the .req files
    except OSError:
        critical.error('Error in finding the request files')
        print("Error in finding the request files")

    file_num = 0
    for file in requested_files:
        non_critical.info('Creating a thread')
        thread = threading.Thread(target=execute_file, args=(file, file_num,))  # Create a thread
        thread.start()
        # thread.join()
        # execute_file(file, file_num)
        print(file_num)  # The file_num to define the file
        file_num += 1


def creating_logger(name, log_file, level=logging.DEBUG):
    # Specify the formate for the logging file
    file_formate = logging.Formatter(
        '{"time":"%(asctime)s", "name": "%(name)s","level": "%(levelname)s", "message": "%(message)s", "ThreadID": '
        '"%(thread)d", "ThreadName": "%(threadName)s"} '
    )

    # Create a file handler
    handler = logging.FileHandler(log_file, mode='a+')
    handler.setFormatter(file_formate)  # Set the format for the file

    logger = logging.getLogger(name)  # Create logger object
    logger.setLevel(level)  # Set the level (DEBUG is the default)
    logger.addHandler(handler)  # Add the handler

    return logger  # Retrun the logger object


# Start the program

# Check if the logging folder is exist
if not os.path.exists('./logging'):
    try:
        os.mkdir('./logging')
    except OSError:
        print("Creating the logging folder is falid")

critical = creating_logger('critical', './logging/critical.log')
non_critical = creating_logger('non_critical', './logging/non_critical.log')

# Check if the request folder is exist
if not os.path.exists('./request'):
    try:
        os.mkdir('./request')
        non_critical.info('Creating the request folder')
    except OSError:
        critical.error('Creating the request folder is falid')
        print("Creating the request folder is falid")

# Check if the processed folder is exist
if not os.path.exists('./request/processed'):
    try:
        os.mkdir('./request/processed')
        non_critical.info('Creating the processed folder')
    except OSError:
        critical.error('Creating the processed folder is falid')
        print("Creating the processed folder is falid")

# Check if the processing folder is exist
if not os.path.exists('./request/processing'):
    try:
        os.mkdir('./request/processing')
        non_critical.info('Creating the processing folder')
    except OSError:
        critical.error('Creating the processing folder is falid')
        print("Creating the processing folder is falid")

# Check if the outbound folder is exist
if not os.path.exists('./outbound'):
    try:
        os.mkdir('./outbound')
        non_critical.info('Creating the outbound folder')
    except OSError:
        critical.error('Creating the outbound folder is falid')
        print("Creating the outbound folder is falid")

# Start the time
start = time.time()


# receive_files()

# schedule.every(1).seconds.do(receive_files)

# while True:
class MainCreate837File:
    def __init__(self):
        # schedule.run_pending()
        time.sleep(1)
        receive_files()

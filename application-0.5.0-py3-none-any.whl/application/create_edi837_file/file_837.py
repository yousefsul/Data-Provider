import json
import os

from bson import ObjectId

from application.ConnectMongoDB import ConnectMongoDB
from application.create_edi837_file.Footer import *
from application.create_edi837_file.Loop1000 import *
from application.create_edi837_file.Loop2000A import *
from application.create_edi837_file.Loop2000B import Loop2000B, Loop2010BB, Loop2010BA
from application.create_edi837_file.Loop2300 import *
from application.create_edi837_file.Loop2400 import *
from application.create_edi837_file.utility import *
from application.parser.parse_837.parse_837 import Parse837

non_critical = logging.getLogger('non_critical.file_873')
critical = logging.getLogger('critical.file_873')


class Trans837:
    sender_id_code = None

    isa13_control_num = str(randint((10 ** 8), ((10 ** 9) - 1)))
    gs06_control_num = str(randint(1, ((10 ** 9) - 1)))

    def __init__(self, data_file_name, input_file_name, payer, receiver):
        self.__mongo_client = "mongodb+srv://yousef:3h2rSzl0pPItpyGp@cluster0.umnlp.mongodb.net/client_2731928905_DB" \
                               "?retryWrites=true&w=majority"
        self.__connection = ConnectMongoDB(self.__mongo_client, 'devDB')
        self.__connection_client = ConnectMongoDB(self.__mongo_client, "client_2731928905_DB")
        self.__connection.connect_to_collection('configColl')
        # Read The Config File
        # try:
        #     non_critical.info('Reading the config file')
        #     with open('./' + data_file_name + '.json') as file:
        #         self.data = json.load(file)
        # except OSError:
        #     critical.error('Error in opening/reading/closing the Config file')
        #     print("Error in opening/reading/closing the Config file")

        self.payer = payer
        self.receiver = receiver
        self.file = ''
        self.ISA = None
        self.GS = None
        self.input_file_name = input_file_name
        self.data = self.__connection.find_from_collection_by_key('_id', ObjectId('61763729ba896ec55c828e5f'))
        if '837' not in self.data[payer][receiver]["transaction_type"]:
            try:
                raise Exception('The 837 transaction type is not available for this receiver')
            except Exception as Ex:
                critical.error('The 837 transaction type is not available for this receiver')
                print(Ex)

    # @staticmethod
    # def __generate_random_num(num_length):
    #     start = 10 ** (num_length - 1)
    #     end = (10 ** num_length) - 1
    #     return randint(start, end)

    def isa_segment(self):
        non_critical.info('Building the isa segment for header')

        # Authorization Information Qualifier
        isa01 = check_ISA_element(self.ISA['ISA01']['length'], self.ISA['ISA01']['data'])

        # Authorization Information
        isa02 = check_ISA_element(self.ISA['ISA02']['length'], self.ISA['ISA02']['data'])

        # Security Information Qualifier
        isa03 = check_ISA_element(self.ISA['ISA03']['length'], self.ISA['ISA03']['data'])

        # Security Information
        isa04 = check_ISA_element(self.ISA['ISA04']['length'], self.ISA['ISA04']['data'])

        # Interchange Id Qualifier Sender
        isa05 = check_ISA_element(self.ISA['ISA05']['length'], self.ISA['ISA05']['data'])

        # Interchange Sender Id
        isa06 = check_ISA_element(self.ISA['ISA06']['length'], self.ISA['ISA06']['data'])
        Trans837.sender_id_code = isa06

        # Interchange Id Qualifier Receiver
        isa07 = check_ISA_element(self.ISA['ISA07']['length'], self.ISA['ISA07']['data'])

        # Interchange Receiver Id
        isa08 = check_ISA_element(self.ISA['ISA08']['length'], self.ISA['ISA08']['data'])

        # Interchange Date
        isa09 = datetime.datetime.now().strftime('%y%m%d')

        # Interchange Time
        isa10 = datetime.datetime.now().strftime('%H%M')

        # Repetition Separator
        isa11 = check_ISA_element(self.ISA['ISA11']['length'], self.ISA['ISA11']['data'])

        # Interchange Control Version Number
        isa12 = check_ISA_element(self.ISA['ISA12']['length'], self.ISA['ISA12']['data'])

        # Interchange Control Number
        isa13 = Trans837.isa13_control_num

        # Acknowledgment Requested
        isa14 = check_ISA_element(self.ISA['ISA14']['length'], self.ISA['ISA14']['data'])

        # Interchange Usage Indicator
        isa15 = check_ISA_element(self.ISA['ISA15']['length'], self.ISA['ISA15']['data'])

        # Component Element Separator
        isa16 = check_ISA_element(self.ISA['ISA16']['length'], self.ISA['ISA16']['data'])

        self.file += 'ISA' + '*' + isa01 + '*' + isa02 + '*' + isa03 + '*' + isa04 + '*' + \
                     isa05 + '*' + isa06 + '*' + isa07 + '*' + isa08 + '*' + isa09 + '*' + \
                     isa10 + '*' + isa11 + '*' + isa12 + '*' + isa13 + '*' + isa14 + '*' + \
                     isa15 + '*' + isa16 + '~'  # + '\n'

    def gs_segment(self):
        non_critical.info('Building the gs segment for header')

        # Functional Identifier Code
        gs01 = check_GS_element(self.GS['GS01']['min'], self.GS['GS01']['max'], self.GS['GS01']['data'])

        # Application Sender’s Code
        gs02 = check_GS_element(self.GS['GS02']['min'], self.GS['GS02']['max'], self.GS['GS02']['data'])

        # Application Receiver’s Code
        gs03 = check_GS_element(self.GS['GS03']['min'], self.GS['GS03']['max'], self.GS['GS03']['data'])

        # Date
        gs04 = datetime.datetime.now().strftime('%Y%m%d')

        # Time
        gs05 = datetime.datetime.now().strftime('%H%M')

        # Group Control Number
        gs06 = Trans837.gs06_control_num

        # Responsible Agency Code
        gs07 = check_GS_element(self.GS['GS07']['min'], self.GS['GS07']['max'], self.GS['GS07']['data'])

        # Version / Release / Industry Identifier Code
        gs08 = check_GS_element(self.GS['GS08']['min'], self.GS['GS08']['max'], self.GS['GS08']['data'])

        self.file += 'GS' + '*' + gs01 + '*' + gs02 + '*' + gs03 + '*' + gs04 + '*' + \
                     gs05 + '*' + gs06 + '*' + gs07 + '*' + gs08 + '~'  # + '\n'

    def prepare_the_file(self):

        # Build The Header

        # Build The ISA Segment
        non_critical.info('Building the isa segment')
        self.ISA = self.data[self.payer][self.receiver]['ISA']
        self.isa_segment()

        # Build The GS Segment
        non_critical.info('Building the gs segment')
        self.GS = self.data[self.payer][self.receiver]['GS']
        self.gs_segment()

        # self.file += '\n'

        # Read The Files

        # Read The Data File
        data = self.__connection.find_from_collection_by_key("_id", ObjectId('6175fe921f462a3a0fcc3913'))

        # try:
        #     non_critical.info('Reading the data file')
        #     with open('./data.json') as file:
        #         data = json.load(file)
        # except OSError:
        #     critical.error('Error in opening/reading/closing the data file')
        #     print("Error in opening/reading/closing the data file")

        # Read The Data Input File (request file)
        try:
            non_critical.info('Reading the input_data file')
            with open(self.input_file_name) as file:
                input_data = json.load(file)
        except OSError:
            critical.error('Error in opening/reading/closing the data_input file')
            print("Error in opening/reading/closing the data_input file")

        st_num = 0
        # Build The Transactions
        for input in input_data["transactions"]:

            num_segments = 0

            # Loop1000

            # Build Loop1000
            Loop1000.generate_random_number(st_num)  # Generate the random variable

            non_critical.info('Building Loop1000')
            loop1000, num_segments_in_loop = Loop1000.all_loop(data["Header"]["ST"], data["Header"]["BHT"])
            self.file += loop1000  # + '\n'

            st_num += 1  # We use it to generate the first 4 digits in the random variable(It gives us the ST number)

            num_segments += num_segments_in_loop  # Count the segments inside the ST

            # Build Loop1000A
            non_critical.info('Building Loop1000A')
            loop1000A, num_segments_in_loop = \
                Loop1000A.all_loop(data["Loop1000A"]["NM1"], Trans837.sender_id_code,
                                   data["Loop1000A"]["PER"], input_data["submitter"])

            self.file += loop1000A  # + '\n'

            num_segments += num_segments_in_loop

            # Build Loop1000B
            non_critical.info('Building Loop1000B')
            loop1000B_nm1, num_segments_in_loop = \
                Loop1000B.all_loop(data["Loop1000B"]["NM1"], self.receiver,
                                   self.data[self.payer][self.receiver]['name'])

            self.file += loop1000B_nm1  # + '\n'

            num_segments += num_segments_in_loop

            # Loop2000

            # Build Loop2000A
            non_critical.info('Building Loop2000A')
            loop2000A_hl, num_segments_in_loop = Loop2000A.all_loop(data["Loop2000A"]["HL"])
            self.file += loop2000A_hl  # + '\n'

            num_segments += num_segments_in_loop

            # Build Loop2010AA
            non_critical.info('Building Loop2010AA')
            loop2010AA, num_segments_in_loop = \
                Loop2010AA.all_loop(data["Loop2010AA"]["NM1"], data["Loop2010AA"]["N3"],
                                    data["Loop2010AA"]["N4"], data["Loop2010AA"]["REF"],
                                    data["Loop2010AA"]["PER"], input['billing_provider'])

            self.file += loop2010AA  # + '\n'

            num_segments += num_segments_in_loop

            # Build Loop2000B
            non_critical.info('Building Loop2000B')
            loop2000B, num_segments_in_loop = Loop2000B.all_loop(data["Loop2000B"]["HL"],
                                                                 data["Loop2000B"]["SBR"], input['subscriber'])
            self.file += loop2000B  # + '\n'

            num_segments += num_segments_in_loop

            # Build Loop2010BA
            non_critical.info('Building Loop2010BA')
            loop2010BA, num_segments_in_loop = \
                Loop2010BA.all_loop(data["Loop2010BA"]["NM1"], data["Loop2010BA"]["N3"],
                                    data["Loop2010BA"]["N4"], data["Loop2010BA"]["DMG"], input['subscriber'])

            self.file += loop2010BA  # + '\n'

            num_segments += num_segments_in_loop

            # Build Loop2010BB
            non_critical.info('Building Loop2010BB')
            loop2010BB, num_segments_in_loop = \
                Loop2010BB.all_loop(data["Loop2010BB"]["NM1"], data["Loop2010BB"]["N3"],
                                    data["Loop2010BB"]["N4"], input['payer'], self.payer,
                                    self.data[self.payer]['name'])

            self.file += loop2010BB  # + '\n'

            num_segments += num_segments_in_loop

            # Loop2300

            # Build Loop2300
            non_critical.info('Building Loop2300')
            loop2300, num_segments_in_loop = Loop2300.all_loop(data["Loop2300"]["CLM"], data["Loop2300"]["DTP"],
                                                               data["Loop2300"]["REF"], data["Loop2300"]["HI"],
                                                               input["claim"],
                                                               input["service_line"][0]["place_of_service"])
            self.file += loop2300  # + '\n'

            num_segments += num_segments_in_loop

            # Build Loop2310A
            non_critical.info('Building Loop2310A')
            loop2310A_nm1, num_segments_in_loop = Loop2310A.all_loop(data["Loop2310A"]["NM1"],
                                                                     input['claim']['referring_provider'])
            self.file += loop2310A_nm1  # + '\n'

            num_segments += num_segments_in_loop

            # Build Loop2310B
            non_critical.info('Building Loop2310B')
            loop2310B, num_segments_in_loop = Loop2310B.all_loop(data["Loop2310B"]["NM1"], data["Loop2310B"]["PRV"],
                                                                 input['claim']['rendering_provider'])
            self.file += loop2310B  # + '\n'

            num_segments += num_segments_in_loop

            # Build Loop2310C
            non_critical.info('Building Loop2310C')
            loop2310C, num_segments_in_loop = Loop2310C.all_loop(data["Loop2310C"]["NM1"], data["Loop2310C"]["N3"],
                                                                 data["Loop2310C"]["N4"], input['facility'])
            self.file += loop2310C  # + '\n'

            num_segments += num_segments_in_loop

            # Loop2400

            # Build Loop2400
            non_critical.info('Building Loop2400')
            lx_num = 1
            for service_line in input["service_line"]:
                loop2400, num_segments_in_loop = \
                    Loop2400.all_loop(data["Loop2400"]["LX"], data["Loop2400"]["SV1"],
                                      data["Loop2400"]["DTP"], data["Loop2400"]["REF"],
                                      service_line, str(lx_num))
                lx_num += 1
                self.file += loop2400  # + '\n'

                num_segments += num_segments_in_loop

            # Build The SE Segment
            non_critical.info('Building the se segment')
            num_segments += 1
            st_footer = SE_Footer.all_loop(data["SE_Footer"]["SE"], Loop1000.st02_bht03, str(num_segments))
            self.file += st_footer  # + '\n'

        # Build The Footer

        # Build The GE/IEA Segment
        non_critical.info('Building the ge and the iea segments')
        iea_ge_footer = IEA_GE_Footer.all_loop(data["IEA_GE_Footer"]["IEA"], Trans837.isa13_control_num,
                                               data["IEA_GE_Footer"]["GE"], Trans837.gs06_control_num,
                                               str(len(input_data["transactions"])), input_data['groups_num'])
        self.file += iea_ge_footer  # + '\n'

        # file_name = shortuuid.uuid()
        file_name = os.path.basename(self.input_file_name).split('.')[0].replace('_837P', '')

        try:
            non_critical.info('Writing the output to outbound folder')
            result_file = open('./outbound/' + file_name + '.837',
                               "w")
            result_file.write(self.file)
            result_file.close()

            parse837 = Parse837(file_name)
            self.__connection_client.connect_to_collection('837_dict_coll')
            self.__connection_client.insert_to_collection(parse837.edi_parsed)
            self.__connection_client.connect_to_collection('index_coll')
            self.__connection_client.insert_to_collection(parse837.index_837)
            self.__connection.close_connection()
            self.__connection_client.close_connection()
        except OSError:
            critical('Error in opening/writing/closing the result file')
            print("Error in opening/writing/closing the result file")

        return self.file

# file_837 = Trans837('config', '62308', '330897513')
# file_837 = Trans837('config', './input_patient_BCBS.json', '53589', '53589')
# result = file_837.prepare_the_file()
# print(result)
# result_file = open("210104.OATEST.000001.837.txt", "w")
# result_file .write(result)
# result_file .close()

# result_file = open("XXXXXXXXX_00009324.837", "w")
# result_file.write(result)
# result_file.close()

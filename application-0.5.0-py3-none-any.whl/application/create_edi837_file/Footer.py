from application.create_edi837_file.utility import check_element_length
import logging

non_critical = logging.getLogger('non_critical.file_873.footer')
critical = logging.getLogger('critical.file_873.footer')

class SE_Footer:

    @staticmethod
    def se_segment(se_data, st02, segments_num):
        non_critical.info('Building the se segment for footer')

        se = se_data

        # Number of Included Segments
        se01 = check_element_length(se['SE01']['min'], se['SE01']['max'], segments_num,
                                    se['SE01']['usage'])

        # Transaction Set Control Number
        se02 = check_element_length(se['SE02']['min'], se['SE02']['max'], st02,
                                    se['SE02']['usage'])

        se = 'SE' + '*' + se01 + '*' + se02 + '~' #+ '\n'

        return se

    @staticmethod
    def all_loop(se_data, st02, segments_num):
        st_footer = ""
        st_footer += SE_Footer.se_segment(se_data, st02, segments_num)

        return st_footer



class IEA_GE_Footer:

    @staticmethod
    def ge_segment(ge_data, gs06, transactions_num):
        non_critical.info('Building the ge segment for footer')

        ge = ge_data

        # Number of Transaction Sets Included
        ge01 = check_element_length(ge['GE01']['min'], ge['GE01']['max'], transactions_num,
                                    ge['GE01']['usage'])

        # Group Control Number
        ge02 = check_element_length(ge['GE02']['min'], ge['GE02']['max'], gs06,
                                    ge['GE02']['usage'])

        ge = 'GE' + '*' + ge01 + '*' + ge02 + '~' #+ '\n'

        return ge

    @staticmethod
    def iea_segment(iea_data, isa13, groups_num):
        non_critical.info('Building the iea segment for footer')
        
        iea = iea_data

        # Number of Included Functional Groups
        iea01 = check_element_length(iea['IEA01']['min'], iea['IEA01']['max'], groups_num,
                                     iea['IEA01']['usage'])

        # Interchange Control Number
        iea02 = check_element_length(iea['IEA02']['min'], iea['IEA02']['max'], isa13,
                                     iea['IEA02']['usage'])

        iea = 'IEA' + '*' + iea01 + '*' + iea02 + '~' #+ '\n'

        return iea

    @staticmethod
    def all_loop(iea_data, isa13, ge_data, gs06, transactions_num, groups_num):
        iea_ge_footer = ""
        iea_ge_footer += IEA_GE_Footer.ge_segment(ge_data, gs06, transactions_num)
        iea_ge_footer += IEA_GE_Footer.iea_segment(iea_data, isa13, groups_num)

        return iea_ge_footer

from random import randint
import datetime
import logging
from application.create_edi837_file.utility import check_element_length

non_critical = logging.getLogger('non_critical.file_873.Loop1000')
critical = logging.getLogger('critical.file_873.Loop1000')

class Loop1000:

    st02_bht03 = None

    @staticmethod
    def generate_random_number(st_num):
        random_num = str(randint(10 ** 4, (10 ** 5) - 1))
        st_num = str(st_num)
        num_zeros = 4 - len(st_num)
        zeros = '0' * num_zeros
        random_num += zeros + st_num

        Loop1000.st02_bht03 = random_num

    @staticmethod
    def st_segment(st_data):
        non_critical.info('Building the st segment for Loop1000')

        st = st_data
        # Transaction Set Identifier Code
        st01 = check_element_length(st['ST01']['min'], st['ST01']['max'], st['ST01']['data'],
                                    st['ST01']['usage'])

        # Transaction Set Control Number
        st02 = Loop1000.st02_bht03

        # Implementation Convention Reference
        st03 = check_element_length(st['ST03']['min'], st['ST03']['max'], st['ST03']['data'],
                                    st['ST03']['usage'])

        st = 'ST' + '*' + st01 + '*' + st02 + '*' + st03 + '~' #+ '\n'

        return st

    @staticmethod
    def bht_segment(bht_data):
        non_critical.info('Building the bht segment  for Loop1000')

        bht = bht_data

        # Hierarchical Structure Code
        bht01 = check_element_length(bht['BHT01']['min'], bht['BHT01']['max'], bht['BHT01']['data'],
                                     bht['BHT01']['usage'])

        # Transaction Set Purpose Code
        bht02 = check_element_length(bht['BHT02']['min'], bht['BHT02']['max'], bht['BHT02']['data'],
                                     bht['BHT02']['usage'])

        # Reference Identification
        bht03 = Loop1000.st02_bht03

        # Date
        bht04 = datetime.datetime.now().strftime('%Y%m%d')

        # Time
        bht05 = datetime.datetime.now().strftime('%H%M')

        # Transaction Type Code
        bht06 = check_element_length(bht['BHT06']['min'], bht['BHT06']['max'], bht['BHT06']['data'],
                                     bht['BHT06']['usage'])

        bht = 'BHT' + '*' + bht01 + '*' + bht02 + '*' + bht03 + '*' + bht04 +\
            '*' + bht05 + '*' + bht06 + '~' #+ '\n'

        return bht

    @staticmethod
    def all_loop(st_data, bht_data):
        num_segments = 0

        loop1000 = ""

        loop1000 += Loop1000.st_segment(st_data)
        num_segments += 1

        loop1000 += Loop1000.bht_segment(bht_data)
        num_segments += 1

        return loop1000, num_segments


class Loop1000A:

    @staticmethod
    def nm1_segment(nm1_data, id_code, submitter_data):
        non_critical.info('Building the nm1 segment for Loop1000A')

        nm1 = nm1_data

        # Entity Identifier Code
        nm101 = check_element_length(nm1['NM101']['min'], nm1['NM101']['max'], nm1['NM101']['data'],
                                     nm1['NM101']['usage'])

        # Entity Type Qualifier
        nm102 = check_element_length(nm1['NM102']['min'], nm1['NM102']['max'], submitter_data["type"],
                                     nm1['NM102']['usage'])

        # Name Last or Organization Name
        nm103 = check_element_length(nm1['NM103']['min'], nm1['NM103']['max'], submitter_data["name"],
                                     nm1['NM103']['usage'])

        # Name First ( SITUATIONAL )
        if submitter_data["type"] == "1":
            nm104 = check_element_length(nm1['NM104']['min'], nm1['NM104']['max'], submitter_data["first_name"],
                                         nm1['NM104']['usage'])
        else:
            nm104 = ""

        # Name Middle ( SITUATIONAL )
        if submitter_data["type"] == "1":
            nm105 = check_element_length(nm1['NM105']['min'], nm1['NM105']['max'], submitter_data["middle_name"],
                                         nm1['NM105']['usage'])
        else:
            nm105 = ""

        # Name Prefix ( not used )
        # nm106 = check_element_length(nm1['NM106']['min'], nm1['NM106']['max'], nm1['NM106']['data'],
        # nm1['NM106']['usage'])
        nm106 = ""

        # Name Suffix ( not used )
        # nm107 = check_element_length(nm1['NM107']['min'], nm1['NM107']['max'], nm1['NM107']['data'],
        # nm1['NM107']['usage'])
        nm107 = ""

        # Identification Code Qualifier
        nm108 = check_element_length(nm1['NM108']['min'], nm1['NM108']['max'], nm1['NM108']['data'],
                                     nm1['NM108']['usage'])

        # Identification Code
        nm109 = check_element_length(nm1['NM109']['min'], nm1['NM109']['max'], id_code.strip(),
                                     nm1['NM109']['usage'])

        nm1 = 'NM1' + '*' + nm101 + '*' + nm102 + '*' + nm103 + '*' + nm104 + \
              '*' + nm105 + '*' + nm106 + '*' + nm107 + '*' + nm108 + '*' + nm109 + '~' #+ '\n'

        return nm1

    @staticmethod
    def per_segment(per_data, submitter_data):
        non_critical.info('Building the per segment for Loop1000A')

        per = per_data

        # Contact Function Code
        per01 = check_element_length(per['PER01']['min'], per['PER01']['max'], per['PER01']['data'],
                                     per['PER01']['usage'])

        # Name ( SITUATIONAL )
        per02 = check_element_length(per['PER02']['min'], per['PER02']['max'], submitter_data["contact"],
                                     per['PER02']['usage'])

        contact_data = "*"
        # Communication Number Qualifier
        per03 = check_element_length(per['PER03']['min'], per['PER03']['max'], submitter_data['contact_type1'],
                                     per['PER03']['usage'])

        # Communication Number
        per04 = check_element_length(per['PER04']['min'], per['PER04']['max'], submitter_data["value1"],
                                     per['PER04']['usage'])

        contact_data += per03 + '*' + per04

        # Communication Number Qualifier ( SITUATIONAL )
        if submitter_data['contact_type2'] != "":
            per05 = check_element_length(per['PER05']['min'], per['PER05']['max'],
                                         submitter_data['contact_type2'], per['PER05']['usage'])

            # Communication Number ( SITUATIONAL )
            per06 = check_element_length(per['PER06']['min'], per['PER06']['max'], submitter_data["value2"],
                                         per['PER06']['usage'])

            contact_data += '*' + per05 + '*' + per06

        # Communication Number Qualifier ( SITUATIONAL )
        if submitter_data['contact_type3'] != "":
            per07 = check_element_length(per['PER07']['min'], per['PER07']['max'],
                                         submitter_data['contact_type3'], per['PER07']['usage'])

            # Communication Number ( SITUATIONAL )
            per08 = check_element_length(per['PER08']['min'], per['PER08']['max'], submitter_data["value3"],
                                         per['PER08']['usage'])

            contact_data += '*' + per07 + '*' + per08

        per = 'PER' + '*' + per01 + '*' + per02 + contact_data + '~' #+ '\n'

        return per

    @staticmethod
    def all_loop(nm1_data, id_code, per_data, submitter_data):
        num_segments = 0

        loop1000A = ""

        loop1000A += Loop1000A.nm1_segment(nm1_data, id_code, submitter_data)
        num_segments += 1

        loop1000A += Loop1000A.per_segment(per_data, submitter_data)
        num_segments += 1

        return loop1000A, num_segments


class Loop1000B:

    @staticmethod
    def nm1_segment(nm1_data, receiver_id, receiver_name):
        non_critical.info('Building the nm1 segment for Loop1000B')

        nm1 = nm1_data

        # Entity Identifier Code
        nm101 = check_element_length(nm1['NM101']['min'], nm1['NM101']['max'], nm1['NM101']['data'],
                                     nm1['NM101']['usage'])

        # Entity Type Qualifier
        nm102 = check_element_length(nm1['NM102']['min'], nm1['NM102']['max'], nm1['NM102']['data'],
                                     nm1['NM102']['usage'])

        # Name Last or Organization Name
        nm103 = check_element_length(nm1['NM103']['min'], nm1['NM103']['max'], receiver_name,
                                     nm1['NM103']['usage'])

        # Name First ( Not Used )
        # nm104 = check_element_length(nm1['NM104']['min'], nm1['NM104']['max'], nm1['NM104']['data'],
        # nm1['NM104']['usage'])
        nm104 = ""

        # Name Middle ( Not Used )
        # nm105 = check_element_length(nm1['NM105']['min'], nm1['NM105']['max'], nm1['NM105']['data'],
        # nm1['NM105']['usage'])
        nm105 = ""

        # Name Prefix ( Not Used )
        # nm106 = check_element_length(nm1['NM106']['min'], nm1['NM106']['max'], nm1['NM106']['data'],
        # nm1['NM106']['usage'])
        nm106 = ""

        # Name Suffix ( Not Used )
        # nm107 = check_element_length(nm1['NM107']['min'], nm1['NM107']['max'], nm1['NM107']['data'],
        # nm1['NM107']['usage'])
        nm107 = ""

        # Identification Code Qualifier
        nm108 = check_element_length(nm1['NM108']['min'], nm1['NM108']['max'], nm1['NM108']['data'],
                                     nm1['NM108']['usage'])

        # Identification Code
        nm109 = check_element_length(nm1['NM109']['min'], nm1['NM109']['max'], receiver_id,
                                     nm1['NM109']['usage'])

        nm1 = 'NM1' + '*' + nm101 + '*' + nm102 + '*' + nm103 + '*' + nm104 + '*' + nm105 + \
            '*' + nm106 + '*' + nm107 + '*' + nm108 + '*' + nm109 + '~' #+ '\n'

        return nm1

    @staticmethod
    def all_loop(nm1_data, id_code, receiver_data):
        num_segments = 0

        loop1000B = ""

        loop1000B += Loop1000B.nm1_segment(nm1_data, id_code, receiver_data)
        num_segments += 1

        return loop1000B, num_segments

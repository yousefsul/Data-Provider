from application.create_edi837_file.utility import check_element_length
import logging

non_critical = logging.getLogger('non_critical.file_873.Loop2400')
critical = logging.getLogger('critical.file_873.Loop2400')

class Loop2400:

    @staticmethod
    def lx_segment(lx_data, lx_num):
        non_critical.info('Building the lx segment for Loop2400')

        lx = lx_data

        # Assigned Number
        lx01 = check_element_length(lx['LX01']['min'], lx['LX01']['max'], lx_num,
                                    lx['LX01']['usage'])

        lx = 'LX' + '*' + lx01 + '~' #+ '\n'

        return lx

    @staticmethod
    def sv1_segment(sv1_data, service_line_data):
        non_critical.info('Building the sv1 segment for Loop2400')

        sv1 = sv1_data

        sv101 = ""
        # COMPOSITE MEDICAL PROCEDURE IDENTIFIER ( Product/Service ID Qualifier )
        sv101_1 = check_element_length(sv1['SV101']['SV101_1']['min'], sv1['SV101']['SV101_1']['max'],
                                       sv1['SV101']['SV101_1']['data'], sv1['SV101']['SV101_1']['usage'])
        sv101 += sv101_1 + ":"

        # COMPOSITE MEDICAL PROCEDURE IDENTIFIER ( Product/Service ID )
        sv101_2 = check_element_length(sv1['SV101']['SV101_2']['min'], sv1['SV101']['SV101_2']['max'],
                                       service_line_data['cpt'], sv1['SV101']['SV101_2']['usage'])
        sv101 += sv101_2 + ":"

        # COMPOSITE MEDICAL PROCEDURE IDENTIFIER ( Procedure Modifier ) ( SITUATIONAL )
        sv101_3 = check_element_length(sv1['SV101']['SV101_3']['min'], sv1['SV101']['SV101_3']['max'],
                                       service_line_data['mod1'], sv1['SV101']['SV101_3']['usage'])
        sv101 += sv101_3 + ":"

        # COMPOSITE MEDICAL PROCEDURE IDENTIFIER ( Procedure Modifier ) ( SITUATIONAL )
        sv101_4 = check_element_length(sv1['SV101']['SV101_4']['min'], sv1['SV101']['SV101_4']['max'],
                                       service_line_data['mod2'], sv1['SV101']['SV101_4']['usage'])
        sv101 += sv101_4 + ":"

        # COMPOSITE MEDICAL PROCEDURE IDENTIFIER ( Procedure Modifier ) ( SITUATIONAL )
        sv101_5 = check_element_length(sv1['SV101']['SV101_5']['min'], sv1['SV101']['SV101_5']['max'],
                                       service_line_data['mod3'], sv1['SV101']['SV101_5']['usage'])
        sv101 += sv101_5 + ":"

        # COMPOSITE MEDICAL PROCEDURE IDENTIFIER ( Procedure Modifier ) ( SITUATIONAL )
        sv101_6 = check_element_length(sv1['SV101']['SV101_6']['min'], sv1['SV101']['SV101_6']['max'],
                                       service_line_data['mod4'], sv1['SV101']['SV101_6']['usage'])
        sv101 += sv101_6 + ":"

        # COMPOSITE MEDICAL PROCEDURE IDENTIFIER ( Description ) ( SITUATIONAL )
        sv101_7 = check_element_length(sv1['SV101']['SV101_7']['min'], sv1['SV101']['SV101_7']['max'],
                                       service_line_data['line_note'], sv1['SV101']['SV101_7']['usage'])
        sv101 += sv101_7 + ":"

        length = len(sv101)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if sv101[i] != ":":
                index = i + 1
                break

        sv101 = sv101[0: index]


        # Monetary Amount
        sv102 = check_element_length(sv1['SV102']['min'], sv1['SV102']['max'], service_line_data['charge'],
                                     sv1['SV102']['usage'])

        # Unit or Basis for Measurement Code
        sv103 = check_element_length(sv1['SV103']['min'], sv1['SV103']['max'], sv1['SV103']['data'],
                                     sv1['SV103']['usage'])

        # Quantity
        sv104 = check_element_length(sv1['SV104']['min'], sv1['SV104']['max'], service_line_data['num_unit'],
                                     sv1['SV104']['usage'])

        # Facility Code Value ( SITUATIONAL )
        sv105 = check_element_length(sv1['SV105']['min'], sv1['SV105']['max'],
                                     service_line_data['place_of_service'], sv1['SV105']['usage'])

        # Service Type Code ( Not Used )
        # sv106 = check_element_length(sv1['SV106']['min'], sv1['SV106']['max'], sv1['SV106']['data'],
        #                                        sv1['SV106']['usage'])
        sv106 = ""

        # COMPOSITE DIAGNOSIS CODE POINTER ( Diagnosis Code Pointer )
        sv107_1 = check_element_length(sv1['SV107']['SV107_1']['min'], sv1['SV107']['SV107_1']['max'],
                                       service_line_data['pointer'][0], sv1['SV107']['SV107_1']['usage'])

        sv107 = sv107_1
        length = len(service_line_data['pointer'])

        for i in range(1, length):
            sv107 += ':'
            sub_elem_name = 'SV107_' + str(i + 1)

            sv107 += check_element_length(sv1['SV107'][sub_elem_name]['min'], sv1['SV107'][sub_elem_name]['max'],
                                          service_line_data['pointer'][i], sv1['SV107'][sub_elem_name]['usage'])

        # # COMPOSITE DIAGNOSIS CODE POINTER ( Diagnosis Code Pointer ) ( SITUATIONAL )
        # sv107_2 = check_element_length(sv1['SV107_2']['min'], sv1['SV107_2']['max'], sv1['SV107_2']['data'],
        #                                sv1['SV107_2']['usage'])
        #
        # # COMPOSITE DIAGNOSIS CODE POINTER ( Diagnosis Code Pointer ) ( SITUATIONAL )
        # sv107_3 = check_element_length(sv1['SV107_3']['min'], sv1['SV107_3']['max'], sv1['SV107_3']['data'],
        #                                sv1['SV107_3']['usage'])
        #
        # # COMPOSITE DIAGNOSIS CODE POINTER ( Diagnosis Code Pointer ) ( SITUATIONAL )
        # sv107_4 = check_element_length(sv1['SV107_4']['min'], sv1['SV107_4']['max'], sv1['SV107_4']['data'],
        #                                sv1['SV107_4']['usage'])

        sv1 = 'SV1' + '*' + sv101 + '*' + sv102 + '*' + sv103 +\
              '*' + sv104 + '*' + sv105 + '*' + sv106 + '*' + sv107 + '~'     # + '\n'

        return sv1

    # Date - Service Date
    @staticmethod
    def dtp_segment(dtp_data, service_line_data):
        non_critical.info('Building the dtp segment for Loop2400')

        dtp = dtp_data

        # Date/Time Qualifier
        dtp01 = check_element_length(dtp['DTP01']['min'], dtp['DTP01']['max'], dtp['DTP01']['data'],
                                     dtp['DTP01']['usage'])

        # Date Time Period Format Qualifier
        dtp02 = check_element_length(dtp['DTP02']['min'], dtp['DTP02']['max'], dtp['DTP02']['data'],
                                     dtp['DTP02']['usage'])

        # Date Time Period
        dtp03 = check_element_length(dtp['DTP03']['min'], dtp['DTP03']['max'], service_line_data['dos'],
                                     dtp['DTP03']['usage'])

        dtp = 'DTP' + '*' + dtp01 + '*' + dtp02 + '*' + dtp03 + '~' #+ '\n'

        return dtp

    # LINE ITEM CONTROL NUMBER
    @staticmethod
    def ref_segment(ref_data, service_line_data):
        non_critical.info('Building the ref segment for Loop2400')
        
        ref = ref_data

        # Reference Identification Qualifier
        ref01 = check_element_length(ref['REF01']['min'], ref['REF01']['max'], ref['REF01']['data'],
                                     ref['REF01']['data'])

        # Reference Identification
        ref02 = check_element_length(ref['REF02']['min'], ref['REF02']['max'],
                                     service_line_data['line_number_control'], ref['REF02']['data'])

        ref = 'REF' + '*' + ref01 + '*' + ref02 + '~' #+ '\n'

        return ref

    @staticmethod
    def all_loop(lx_data, sv1_data, dtp_data, ref_data, service_line_data, lx_num):
        num_segments = 0

        loop2400 = ""

        loop2400 += Loop2400.lx_segment(lx_data, lx_num)
        num_segments += 1

        loop2400 += Loop2400.sv1_segment(sv1_data, service_line_data)
        num_segments += 1

        loop2400 += Loop2400.dtp_segment(dtp_data, service_line_data)
        num_segments += 1

        if service_line_data['line_number_control'] != "":
            loop2400 += Loop2400.ref_segment(ref_data, service_line_data)
            num_segments += 1

        return loop2400, num_segments


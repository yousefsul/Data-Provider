from application.create_edi837_file.utility import check_element_length
import logging

non_critical = logging.getLogger('non_critical.file_873.Loop2300')
critical = logging.getLogger('critical.file_873.Loop2300')

class Loop2300:

    @staticmethod
    def clm_segment(clm_data, claim_input_data, place_of_service):
        non_critical.info('Building the clm segment for Loop2300')

        clm = clm_data

        # Claim Submitter’s Identifier
        clm01 = check_element_length(clm['CLM01']['min'], clm['CLM01']['max'], claim_input_data['number'],
                                     clm['CLM01']['usage'])

        # Monetary Amount
        clm02 = check_element_length(clm['CLM02']['min'], clm['CLM02']['max'], claim_input_data['charges'],
                                     clm['CLM02']['usage'])

        # Claim Filing Indicator Code ( Not Used )
        # clm03 = check_element_length(clm['CLM03']['min'], clm['CLM03']['max'], clm['CLM03']['data'],
        # clm['CLM03']['usage'])
        clm03 = ""

        # Non-Institutional Claim Type Code ( Not Used )
        # clm04 = check_element_length(clm['CLM04']['min'], clm['CLM04']['max'], clm['CLM04']['data'],
        # clm['CLM04']['usage'])
        clm04 = ""

        # HEALTH CARE SERVICE LOCATION INFORMATION ( Facility Code Value )
        clm05_1 = check_element_length(clm['CLM05']['CLM05_1']['min'], clm['CLM05']['CLM05_1']['max'],
                                       place_of_service, clm['CLM05']['CLM05_1']['usage'])

        # HEALTH CARE SERVICE LOCATION INFORMATION ( Facility Code Qualifier )
        clm05_2 = check_element_length(clm['CLM05']['CLM05_2']['min'], clm['CLM05']['CLM05_2']['max'],
                                       clm['CLM05']['CLM05_2']['data'], clm['CLM05']['CLM05_2']['usage'])

        # HEALTH CARE SERVICE LOCATION INFORMATION ( Claim Frequency Type Code )
        clm05_3 = check_element_length(clm['CLM05']['CLM05_3']['min'], clm['CLM05']['CLM05_3']['max'],
                                       claim_input_data['frequency'], clm['CLM05']['CLM05_3']['usage'])

        # Yes/No Condition or Response Code
        clm06 = check_element_length(clm['CLM06']['min'], clm['CLM06']['max'],
                                     claim_input_data['provider_signature_indicator'], clm['CLM06']['usage'])

        # Provider Accept Assignment Code
        clm07 = check_element_length(clm['CLM07']['min'], clm['CLM07']['max'],
                                     claim_input_data['accept_assignment'], clm['CLM07']['usage'])

        # Yes/No Condition or Response Code
        clm08 = check_element_length(clm['CLM08']['min'], clm['CLM08']['max'], claim_input_data['certification'],
                                     clm['CLM08']['usage'])

        # Release of Information Code
        clm09 = check_element_length(clm['CLM09']['min'], clm['CLM09']['max'],
                                     claim_input_data['release_of_info'], clm['CLM09']['usage'])

        # Patient Signature Source Code ( SITUATIONAL )
        clm10 = ""
        if clm['CLM10']['data'] != "":
            clm10 += '*'
            clm10 += check_element_length(clm['CLM10']['min'], clm['CLM10']['max'], clm['CLM10']['data'],
                                          clm['CLM10']['usage'])

        clm = 'CLM' + '*' + clm01 + '*' + clm02 + '*' + clm03 + '*' + clm04 + \
              '*' + clm05_1 + ':' + clm05_2 + ':' + clm05_3 + '*' + clm06 + '*' +\
              clm07 + '*' + clm08 + '*' + clm09 + clm10 + '~' #+ '\n'

        return clm

    # Date - Onset of Current Illness or Symptom
    @staticmethod
    def dtp_segment(dtp_data, claim_input_data):
        non_critical.info('Building the dtp segment for Loop2300')

        dtp = dtp_data

        # Date/Time Qualifier
        dtp01 = check_element_length(dtp['DTP01']['min'], dtp['DTP01']['max'], dtp['DTP01']['data'],
                                     dtp['DTP01']['usage'])

        # Date Time Period Format Qualifier
        dtp02 = check_element_length(dtp['DTP02']['min'], dtp['DTP02']['max'], dtp['DTP02']['data'],
                                     dtp['DTP02']['usage'])

        # Date Time Period
        dtp03 = check_element_length(dtp['DTP03']['min'], dtp['DTP03']['max'],
                                     claim_input_data['onset_of_current_illness'], dtp['DTP03']['usage'])

        dtp = 'DTP' + '*' + dtp01 + '*' + dtp02 + '*' + dtp03 + '~' #+ '\n'

        return dtp

    # Prior Authorization
    @staticmethod
    def ref_segment(ref_data, claim_input_data):
        non_critical.info('Building the ref segment for Loop2300')

        ref = ref_data

        # Reference Identification Qualifier
        ref01 = check_element_length(ref['REF01']['min'], ref['REF01']['max'], ref['REF01']['data'],
                                     ref['REF01']['usage'])

        # Reference Identification
        ref02 = check_element_length(ref['REF02']['min'], ref['REF02']['max'], claim_input_data['authorization'],
                                     ref['REF02']['usage'])

        ref = 'REF' + '*' + ref01 + '*' + ref02 + '~' #+ '\n'

        return ref

    # HEALTH CARE DIAGNOSIS CODE
    @staticmethod
    def hi_segment(hi_data, claim_input_data):
        non_critical.info('Building the hi segment for Loop2300')

        hi = hi_data

        # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code )
        hi01_1 = check_element_length(hi['HI01']['HI01_1']['min'], hi['HI01']['HI01_1']['max'],
                                      hi_data['HI01']['HI01_1']['data'], hi['HI01']['HI01_1']['usage'])

        # HEALTH CARE CODE INFORMATION ( Industry Code )
        hi01_2 = check_element_length(hi['HI01']['HI01_2']['min'], hi['HI01']['HI01_2']['max'],
                                      claim_input_data['DX_code'][0], hi['HI01']['HI01_2']['usage'])

        hi_content = '*' + hi01_1 + ':' + hi01_2
        length = len(claim_input_data['DX_code'])

        for i in range(1, length):

            hi_content += '*'

            if (i + 1) < 10:
                ele_num = "HI0" + str(i + 1)
            else:
                ele_num = "HI" + str(i + 1)

            sub_ele_num = ele_num + '_1'

            hi_content += check_element_length(hi[ele_num][sub_ele_num]['min'],
                                               hi[ele_num][sub_ele_num]['max'],
                                               hi_data[ele_num][sub_ele_num]['data'],
                                               hi[ele_num][sub_ele_num]['usage'])

            hi_content += ':'

            sub_ele_num = ele_num + '_2'

            hi_content += check_element_length(hi[ele_num][sub_ele_num]['min'],
                                               hi[ele_num][sub_ele_num]['max'],
                                               claim_input_data['DX_code'][i],
                                               hi[ele_num][sub_ele_num]['usage'])

        # # HEALTH CARE CODE INFORMATION ( Industry Code )
        # hi01_2 = check_element_length(hi['HI01_2']['min'], hi['HI01_2']['max'], hi['HI01_2']['data'],
        #                               hi['HI01_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi02_1 = check_element_length(hi['HI02_1']['min'], hi['HI02_1']['max'], hi['HI02_1']['data'],
        #                               hi['HI02_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi02_2 = check_element_length(hi['HI02_2']['min'], hi['HI02_2']['max'], hi['HI02_2']['data'],
        #                               hi['HI02_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi03_1 = check_element_length(hi['HI03_1']['min'], hi['HI03_1']['max'], hi['HI03_1']['data'],
        #                               hi['HI03_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi03_2 = check_element_length(hi['HI03_2']['min'], hi['HI03_2']['max'], hi['HI03_2']['data'],
        #                               hi['HI03_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi04_1 = check_element_length(hi['HI04_1']['min'], hi['HI04_1']['max'], hi['HI04_1']['data'],
        #                               hi['HI04_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi04_2 = check_element_length(hi['HI04_2']['min'], hi['HI04_2']['max'], hi['HI04_2']['data'],
        #                               hi['HI04_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi05_1 = check_element_length(hi['HI05_1']['min'], hi['HI05_1']['max'], hi['HI05_1']['data'],
        #                               hi['HI05_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi05_2 = check_element_length(hi['HI05_2']['min'], hi['HI05_2']['max'], hi['HI05_2']['data'],
        #                               hi['HI05_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi06_1 = check_element_length(hi['HI06_1']['min'], hi['HI06_1']['max'], hi['HI06_1']['data'],
        #                               hi['HI06_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi06_2 = check_element_length(hi['HI06_2']['min'], hi['HI06_2']['max'], hi['HI06_2']['data'],
        #                               hi['HI06_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi07_1 = check_element_length(hi['HI07_1']['min'], hi['HI07_1']['max'], hi['HI07_1']['data'],
        #                               hi['HI07_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi07_2 = check_element_length(hi['HI07_2']['min'], hi['HI07_2']['max'], hi['HI07_2']['data'],
        #                               hi['HI07_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code  ( Required Inside SITUATIONAL )
        # hi08_1 = check_element_length(hi['HI08_1']['min'], hi['HI08_1']['max'], hi['HI08_1']['data'],
        #                               hi['HI08_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi08_2 = check_element_length(hi['HI08_2']['min'], hi['HI08_2']['max'], hi['HI08_2']['data'],
        #                               hi['HI08_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi09_1 = check_element_length(hi['HI09_1']['min'], hi['HI09_1']['max'], hi['HI09_1']['data'],
        #                               hi['HI09_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi09_2 = check_element_length(hi['HI09_2']['min'], hi['HI09_2']['max'], hi['HI09_2']['data'],
        #                               hi['HI09_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi10_1 = check_element_length(hi['HI10_2']['min'], hi['HI10_1']['max'], hi['HI10_1']['data'],
        #                               hi['HI10_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi10_2 = check_element_length(hi['HI10_2']['min'], hi['HI10_2']['max'], hi['HI10_2']['data'],
        #                               hi['HI10_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi11_1 = check_element_length(hi['HI11_1']['min'], hi['HI11_1']['max'], hi['HI11_1']['data'],
        #                               hi['HI11_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi11_2 = check_element_length(hi['HI11_2']['min'], hi['HI11_2']['max'], hi['HI11_2']['data'],
        #                               hi['HI11_2']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Code List Qualifier Code ) ( Required Inside SITUATIONAL )
        # hi12_1 = check_element_length(hi['HI12_1']['min'], hi['HI12_1']['max'], hi['HI12_1']['data'],
        #                               hi['HI12_1']['usage'])
        #
        # # HEALTH CARE CODE INFORMATION ( Industry Code ) ( Required Inside SITUATIONAL )
        # hi12_2 = check_element_length(hi['HI12_2']['min'], hi['HI12_2']['max'], hi['HI12_2']['data'],
        #                               hi['HI12_2']['usage'])

        hi = 'HI' + hi_content + '~' #+ '\n'

        return hi

    @staticmethod
    def all_loop(clm_data, dtp_data, ref_data, hi_data, claim_input_data, place_of_service):
        num_segments = 0

        loop2300 = ""

        loop2300 += Loop2300.clm_segment(clm_data, claim_input_data, place_of_service)
        num_segments += 1

        if claim_input_data['onset_of_current_illness'] != "":
            loop2300 += Loop2300.dtp_segment(dtp_data, claim_input_data)
            num_segments += 1

        if claim_input_data['authorization'] != "":
            loop2300 += Loop2300.ref_segment(ref_data, claim_input_data)
            num_segments += 1

        loop2300 += Loop2300.hi_segment(hi_data, claim_input_data)
        num_segments += 1

        return loop2300, num_segments


class Loop2310A:

    @staticmethod
    def nm1_segment(nm1_data, referring_provider_data):
        non_critical.info('Building the nm1 segment for Loop2310A')

        nm1 = nm1_data

        # Entity Identifier Code
        nm101 = check_element_length(nm1['NM101']['min'], nm1['NM101']['max'], nm1['NM101']['data'],
                                     nm1['NM101']['usage'])

        # Entity Type Qualifier
        nm102 = check_element_length(nm1['NM102']['min'], nm1['NM102']['max'], referring_provider_data['type'],
                                     nm1['NM102']['usage'])

        # Name Last or Organization Name
        nm103 = check_element_length(nm1['NM103']['min'], nm1['NM103']['max'],
                                     referring_provider_data['last_name'], nm1['NM103']['usage'])

        # Name First ( SITUATIONAL )
        nm104 = check_element_length(nm1['NM104']['min'], nm1['NM104']['max'],
                                     referring_provider_data['first_name'], nm1['NM104']['usage'])
        # Name Middle ( SITUATIONAL )
        nm105 = check_element_length(nm1['NM105']['min'], nm1['NM105']['max'],
                                     referring_provider_data['middle_name'], nm1['NM105']['usage'])

        # Name Prefix ( Not Used )
        # nm106 = check_element_length(nm1['NM106']['min'], nm1['NM106']['max'], nm1['NM106']['data'],
        #                                      nm1['NM106']['usage'])
        nm106 = ""

        # Name Suffix ( SITUATIONAL )
        nm107 = check_element_length(nm1['NM107']['min'], nm1['NM107']['max'],
                                     referring_provider_data['suffix'], nm1['NM107']['usage'])

        # Identification Code Qualifier ( SITUATIONAL )
        nm108 = check_element_length(nm1['NM108']['min'], nm1['NM108']['max'], nm1['NM108']['data'],
                                     nm1['NM108']['usage'])

        # Identification Code ( SITUATIONAL )
        nm109 = check_element_length(nm1['NM109']['min'], nm1['NM109']['max'],
                                     referring_provider_data['npi'], nm1['NM109']['usage'])

        nm1 = 'NM1' + '*' + nm101 + '*' + nm102 + '*' + nm103 + '*' + nm104 + \
              '*' + nm105 + '*' + nm106 + '*' + nm107 + '*' + nm108 + '*' + nm109

        length = len(nm1)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if nm1[i] != '*':
                index = i + 1
                break

        nm1 = nm1[0: index]
        nm1 += '~' #+ '\n')

        return nm1

    @staticmethod
    def all_loop(nm1_data, referring_provider_data):
        num_segments = 0

        loop2310A = ""

        if referring_provider_data['type'] != "" and referring_provider_data['last_name'] != "":
            loop2310A += Loop2310A.nm1_segment(nm1_data, referring_provider_data)
            num_segments += 1

        return loop2310A, num_segments



class Loop2310B:

    @staticmethod
    def nm1_segment(nm1_data, rendering_provider_data):
        non_critical.info('Building the nm1 segment for Loop2310B')

        nm1 = nm1_data

        # Entity Identifier Code
        nm101 = check_element_length(nm1['NM101']['min'], nm1['NM101']['max'], nm1['NM101']['data'],
                                     nm1['NM101']['usage'])

        # Entity Type Qualifier
        nm102 = check_element_length(nm1['NM102']['min'], nm1['NM102']['max'], rendering_provider_data['type'],
                                     nm1['NM102']['usage'])

        # Name Last or Organization Name
        nm103 = check_element_length(nm1['NM103']['min'], nm1['NM103']['max'],
                                     rendering_provider_data['last_name'], nm1['NM103']['usage'])

        # Name First ( SITUATIONAL )
        nm104 = check_element_length(nm1['NM104']['min'], nm1['NM104']['max'],
                                     rendering_provider_data['first_name'], nm1['NM104']['usage'])

        # Name Middle ( SITUATIONAL )
        nm105 = check_element_length(nm1['NM105']['min'], nm1['NM105']['max'],
                                     rendering_provider_data['middle_name'], nm1['NM105']['usage'])

        # Name Prefix ( Not Used )
        # nm106 = check_element_length(nm1['NM106']['min'], nm1['NM106']['max'], nm1['NM106']['data'],
        #                                      nm1['NM106']['usage'])
        nm106 = ""

        # Name Suffix ( SITUATIONAL )
        nm107 = check_element_length(nm1['NM107']['min'], nm1['NM107']['max'],
                                     rendering_provider_data['suffix'], nm1['NM107']['usage'])

        # Identification Code Qualifier ( SITUATIONAL )
        nm108 = check_element_length(nm1['NM108']['min'], nm1['NM108']['max'], nm1['NM108']['data'],
                                     nm1['NM108']['usage'])

        # Identification Code ( SITUATIONAL )
        nm109 = check_element_length(nm1['NM109']['min'], nm1['NM109']['max'], rendering_provider_data['npi'],
                                     nm1['NM109']['usage'])

        nm1 = 'NM1' + '*' + nm101 + '*' + nm102 + '*' + nm103 + '*' + nm104 + \
              '*' + nm105 + '*' + nm106 + '*' + nm107 + '*' + nm108 + '*' + nm109

        length = len(nm1)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if nm1[i] != '*':
                index = i + 1
                break

        nm1 = nm1[0: index]
        nm1 += '~' #+ '\n')

        return nm1

    @staticmethod
    def prv_segment(prv_data, rendering_provider_data):
        non_critical.info('Building the prv segment for Loop2310A')

        prv = prv_data

        # Provider Code
        prv01 = check_element_length(prv['PRV01']['min'], prv['PRV01']['max'], prv['PRV01']['data'],
                                     prv['PRV01']['usage'])

        # Reference Identification Qualifier
        prv02 = check_element_length(prv['PRV02']['min'], prv['PRV02']['max'], prv['PRV02']['data'],
                                     prv['PRV02']['usage'])

        # Reference Identification
        prv03 = check_element_length(prv['PRV03']['min'], prv['PRV03']['max'],
                                     rendering_provider_data['taxonomy'], prv['PRV03']['usage'])

        prv = 'PRV' + '*' + prv01 + '*' + prv02 + '*' + prv03 + '~' #+ '\n'

        return prv

    @staticmethod
    def all_loop(nm1_data, prv_data, rendering_provider_data):
        num_segments = 0

        loop2310B = ""

        if rendering_provider_data['type'] != "" and rendering_provider_data['last_name'] != "":
            loop2310B += Loop2310B.nm1_segment(nm1_data, rendering_provider_data)
            num_segments += 1

        if rendering_provider_data['taxonomy'] != "":
            loop2310B += Loop2310B.prv_segment(prv_data, rendering_provider_data)
            num_segments += 1

        return loop2310B, num_segments


class Loop2310C:

    @staticmethod
    def nm1_segment(nm1_data, facility_data):
        non_critical.info('Building the nm1 segment for Loop2310C')

        nm1 = nm1_data

        # Entity Identifier Code
        nm101 = check_element_length(nm1['NM101']['min'], nm1['NM101']['max'], nm1['NM101']['data'],
                                     nm1['NM101']['usage'])

        # Entity Type Qualifier
        nm102 = check_element_length(nm1['NM102']['min'], nm1['NM102']['max'], facility_data['type'],
                                     nm1['NM102']['usage'])

        # Name Last or Organization Name
        nm103 = check_element_length(nm1['NM103']['min'], nm1['NM103']['max'], facility_data['name'],
                                     nm1['NM103']['usage'])

        # Name First ( Not Used )
        # nm104 = check_element_length(nm1['NM104']['min'], nm1['NM104']['max'], nm1['NM104']['data'],
        #                                      nm1['NM104']['usage'])
        nm104 = ""

        # Name Middle ( Not Used )
        # nm105 = check_element_length(nm1['NM105']['min'], nm1['NM105']['max'], nm1['NM105']['data'],
        #                                      nm1['NM105']['usage'])
        nm105 = ""

        # Name Prefix ( Not Used )
        # nm106 = check_element_length(nm1['NM106']['min'], nm1['NM106']['max'], nm1['NM106']['data'],
        #                                      nm1['NM106']['usage'])
        nm106 = ""

        # Name Suffix ( Not Used )
        # nm107 = check_element_length(nm1['NM107']['min'], nm1['NM107']['max'], nm1['NM107']['data'],
        #                                      nm1['NM107']['usage'])
        nm107 = ""

        # Identification Code Qualifier ( SITUATIONAL )
        nm108 = check_element_length(nm1['NM108']['min'], nm1['NM108']['max'], nm1['NM108']['data'],
                                     nm1['NM108']['usage'])

        # Identification Code ( SITUATIONAL )
        nm109 = check_element_length(nm1['NM109']['min'], nm1['NM109']['max'], facility_data['npi'],
                                     nm1['NM109']['usage'])

        nm1 = 'NM1' + '*' + nm101 + '*' + nm102 + '*' + nm103 + '*' + nm104 + \
              '*' + nm105 + '*' + nm106 + '*' + nm107 + '*' + nm108 + '*' + nm109

        length = len(nm1)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if nm1[i] != '*':
                index = i + 1
                break

        nm1 = nm1[0: index]
        nm1 += '~' #+ '\n')

        return nm1

    @staticmethod
    def n3_segment(n3_data, facility_data):
        non_critical.info('Building the n3 segment for Loop2310C')

        n3 = n3_data

        # Address Information
        n301 = check_element_length(n3['N301']['min'], n3['N301']['max'], facility_data['address'],
                                    n3['N301']['usage'])

        # Address Information ( Not Used In The Default )
        # n302 = check_element_length(n3['N302']['min'], n3['N302']['max'], n3['N302']['data'],
        #                                     n3['N302']['usage'])

        n3 = 'N3' + '*' + n301 + '~' #+ '\n'

        return n3

    @staticmethod
    def n4_segment(n4_data, facility_data):
        non_critical.info('Building the n4 segment for Loop2310C')

        n4 = n4_data

        # City Name
        n401 = check_element_length(n4['N401']['min'], n4['N401']['max'], facility_data['city'],
                                    n4['N401']['usage'])

        # State or Province Code ( SITUATIONAL )
        n402 = check_element_length(n4['N402']['min'], n4['N402']['max'], facility_data['state'],
                                    n4['N402']['usage'])

        # Postal Code ( SITUATIONAL )
        n403 = check_element_length(n4['N403']['min'], n4['N403']['max'], facility_data['zip_code'],
                                    n4['N403']['usage'])

        # Country Code ( Not Used In The Default ) ( SITUATIONAL )
        # n404 = check_element_length(n4['N404']['min'], n4['N404']['max'], n4['N404']['data'],
        #                                     n4['N404']['usage'])

        # Location Qualifier ( not used )
        # n405 = check_element_length(n4['N405']['min'], n4['N405']['max'], n4['N405']['data'],
        #                                     n4['N405']['usage'])
        # n405 = ""

        # Location Identifier ( not used )
        # n406 = check_element_length(n4['N406']['min'], n4['N406']['max'], n4['N406']['data'],
        #                                     n4['N406']['usage'])
        # n406 = ""

        # Country Subdivision Code ( Not Used In The Default ) ( SITUATIONAL )
        # n407 = check_element_length(n4['N407']['min'], n4['N407']['max'], n4['N407']['data'],
        #                                     n4['N407']['usage'])

        n4 = 'N4' + '*' + n401 + '*' + n402 + '*' + n403

        length = len(n4)
        length -= 1
        index = None
        for i in range(length, 0, -1):
            if n4[i] != '*':
                index = i + 1
                break

        n4 = n4[0: index]
        n4 += '~' #+ '\n')

        return n4

    @staticmethod
    def all_loop(nm1_data, n3_data, n4_data, facility_data):
        num_segments = 0

        loop2310C = ""

        if facility_data['type'] != "" and facility_data['name']:
            loop2310C += Loop2310C.nm1_segment(nm1_data, facility_data)
            num_segments += 1

        loop2310C += Loop2310C.n3_segment(n3_data, facility_data)
        num_segments += 1

        loop2310C += Loop2310C.n4_segment(n4_data, facility_data)
        num_segments += 1

        return loop2310C, num_segments
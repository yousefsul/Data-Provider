import datetime
import shortuuid


class CommonMethodUsed:
    def __init__(self):
        self.__id = None
        self.__current_status_dict = None
        self.__date = datetime.datetime.now().date().strftime("%Y%m%d")
        self.__time = datetime.datetime.now().time().strftime("%H:%M:%S")
        self.__amount_to_convert = float


    def generate_numeric_random_id(self, id_length):
        self.__id = int(shortuuid.ShortUUID(alphabet="0123456789").random(length=id_length).lower())
        return self.__id

    def generate_alphanumeric_random_id(self, id_length):
        self.__id = shortuuid.ShortUUID().random(length=id_length).lower()
        return self.__id

    def generate_new_status_header(self):
        self.__current_status_dict = {
            "status": "new",
            "date": {
                "date": self.__date,
                "time": self.__time
            }
        }
        return self.__current_status_dict

    def convert_string_float_num(self, amount):
        self.__amount_to_convert = amount
        return format(float(self.__amount_to_convert), '.2f')


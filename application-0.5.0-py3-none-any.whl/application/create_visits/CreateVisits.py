import codecs
import datetime
import json
import os
from pathlib import Path
from time import strftime

import shortuuid

from application.create_visits.ClientInfo import ClientInfo
from application.create_visits.VisitInfo import VisitInfo
from application.mongodb_connection.ConnectMongoDBVisits import ConnectMongoDBVisits
from application.send_email.SendEmail import SendEmail

"""
class Search

Methods:

constructor  -->
    params no params

    call from --> main method
----------------------------------------------------------
search_patients_appointments
    params no params

    call from --> main method
----------------------------------------------------------
Functions:
merge_patient_appointment -->
    params tow dictionary : the first one for the appointment and the second one for the patent

    call from --> search_patients_appointments method

    return merged dictionary for the tow dictionaries
----------------------------------------------------------
get_current_status -->
    params no params 
    
    call from create_visits method
----------------------------------------------------------
generate_visit_id -->
    params no params 
    
    call from create_visits method
    """


# return merged dictionary for the appointment and patient
def merge_patient_appointment(patient_data, appointment_data):
    res = {**patient_data, **appointment_data}
    return res


# create visit with current status new
def get_current_status():
    current_status = {
        "status": "new",
        "date": {
            "date": datetime.datetime.now().date().strftime("%Y%m%d"),
            "time": datetime.datetime.now().time().strftime("%H:%M:%S")
        }
    }
    return current_status


# return id for each new visit
def generate_visit_id():
    return int(shortuuid.ShortUUID(alphabet="0123456789").random(length=10).lower())


class CreateVisits:
    """
    define patients,appointment,patient_data,appointment_data as none
    define visits_data lists to have all visits for patients
    define visit date and time created
    create object from class ConnectMongoDB named connection
    """

    def __init__(self):
        self.patients = None
        self.appointments = None
        self.__patient_data = None
        self.__appointment_data = None
        self.__flag = False
        self.__flag_send = False
        self.__visits_data = []
        self.__visit_date = datetime.datetime.now().date().strftime("%Y%m%d")
        self.__visit_time = datetime.datetime.now().time().strftime("%H:%M:%S")
        self.__status_history = [get_current_status()]
        self.__send_email = SendEmail(self.__set_text(), self.__set_html())
        self.__missing_patient_file = open(f'files/logs/{self.__visit_date + "_" + strftime("%H%M%S")}.txt', 'w')
        self.__connection = ConnectMongoDBVisits()
        self.__search_patients_appointments()
        self.__create_visits()
        self.__connection.close_connection()

    """
    get the patients and appointments from database search for the matching result by name 
    call merge_patient_appointment method and append the result to visits list 
    """

    def __search_patients_appointments(self):
        self.__connection.connect_to_patients_collection()
        self.__connection.connect_to_appointments_collection()
        self.__patient_data = self.__connection.get_patients_data()
        self.__appointment_data = self.__connection.get_appointments_data()
        for appointment_data in self.__appointment_data:
            self.__flag = False
            for patient_data in self.__patient_data:
                if appointment_data.get("patient_name")["last"] == \
                        patient_data.get("patient_info")["patient_name"]["last"] \
                        and appointment_data.get("patient_name")["first"] == \
                        patient_data.get("patient_info")["patient_name"]["first"]:
                    self.__visits_data.append(merge_patient_appointment(patient_data, appointment_data))
                    self.__patient_data.rewind()
                    self.__flag = True
                    break
            if self.__flag:
                self.__patient_data.rewind()
            else:
                self.__missing_patient_file.write(
                    json.dumps(
                        str(appointment_data.get("patient_name")) + "," + " Date of service: " +
                        appointment_data.get("date_of_service")) + '\n')
                self.__flag_send = True
                self.__patient_data.rewind()

    """
    get the client information and construct the visits sections 
    insert the result in database 
    """

    def __create_visits(self):
        self.__missing_patient_file.close()
        if self.__flag_send:
            self.__send_email.send_email(self.__missing_patient_file)
        else:
            os.remove(self.__missing_patient_file.name)
        self.__connection.connect_to_visits_collection()
        self.__connection.connect_to_client_collection()
        client = self.__connection.get_afroza_ahmed_info()
        client_info = ClientInfo(client)
        rendering_provider_info = client_info.get_rendering_provider_info()
        for visit in self.__visits_data:
            visit_info = VisitInfo(visit, rendering_provider_info)
            result = {
                "header_section": {
                    "visit_id": generate_visit_id(),
                    "date_created": {
                        "date": self.__visit_date,
                        "time": self.__visit_time
                    },
                    "current_status": get_current_status(),
                    "status_history": self.__status_history
                },
                "client_info": client_info.get_client_info(),
                "patient_info": visit_info.get_patient_info(),
                "insurance_info": {
                    "primary_insurance": visit_info.get_primary_insurance(),
                    "secondary_insurance": visit_info.get_secondary_insurance(),
                    "tertiary_insurance": visit_info.get_tertiary_insurance()
                },
                "home_plan_insurance": visit_info.get_home_plan_insurance(),
                "plan_admin": visit_info.get_plan_admin(),
                "service_facility_info": client_info.get_service_facility_info(),
                "billing_provider_info": client_info.get_billing_provider_info(),
                "events_date": visit_info.get_events_date(),
                "miscellaneous": {"prior_authorization_number": ""},
                "physician": {
                    "ordering": visit_info.get_physician_ordering(),
                    "referring": visit_info.get_referring_ordering(),
                    "supervising": visit_info.get_supervising_ordering(),
                },
                "service_line": visit_info.get_service_line()
            }
            self.__connection.insert_to_visits_collection(result)
            self.__connection.update_status_for_appointment_collection(visit_info.get_appointment_id())
            self.__connection.update_appointment_current_status(visit_info.get_appointment_id())

    def __set_html(self):
        self.__html = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>MEDVERTEX EMAIL NOTIFICATION</title>
        </head>
        
            <body>
                <div class="email_header">
                    <h5 style="color: #e72e0f">MEDVERTEX EMAIL NOTIFICATION</h5>
                </div>
        
                <div class="email_body">
                    <p>Hello,<br><br>
                       Hope this email finds you well,
                       Please find the attachment file for missing patients on patients excel sheet. <br>
                    </p>
                    <h5>
                       <a href="https://www.medvertex.com">MEDVERTEX</a>
                    </h5>
                </div>
            </body>
        </html>
        """
        return self.__html

    def __set_text(self):
        self.__text = """\
        File Notification,
        www.medvertex.com"""
        return self.__text
